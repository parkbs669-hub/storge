# 가상 팀 회의 시뮬레이터 v2 — 의제 분해 + 결정 원장 + 맥락 주입 (로컬 LLM 지원 & 무의존성 모드)

import os
import sys
import time
import re
import threading
import json
import urllib.request

# 1. 의존성 예외 처리 (다른 컴퓨터 실행 대비)
# colorama 라이브러리 체크 및 대비
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    HAS_COLORAMA = True
except ImportError:
    HAS_COLORAMA = False
    # 컬러 출력이 불가능할 경우 빈 문자열로 처리하는 더미 클래스
    class DummyColor:
        def __getattr__(self, name):
            return ""
    Fore = DummyColor()
    Style = DummyColor()

# msvcrt (Windows 키입력 감지) 체크 및 대비
try:
    import msvcrt
    HAS_MSVCRT = True
except ImportError:
    HAS_MSVCRT = False

sys.stdout.reconfigure(encoding='utf-8') if hasattr(sys.stdout, 'reconfigure') else None


class Spinner:
    def __init__(self, message="생각 중..."):
        self.message = message
        self.stop_event = threading.Event()
        self.thread = None

    def spin(self):
        chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        idx = 0
        while not self.stop_event.is_set():
            sys.stdout.write(f"\r{Fore.WHITE}{Style.DIM}{chars[idx]} {self.message}")
            sys.stdout.flush()
            idx = (idx + 1) % len(chars)
            time.sleep(0.08)
        sys.stdout.write("\r" + " " * (len(self.message) + 15) + "\r")
        sys.stdout.flush()

    def start(self):
        self.stop_event.clear()
        self.thread = threading.Thread(target=self.spin, daemon=True)
        self.thread.start()

    def stop(self):
        if self.thread:
            self.stop_event.set()
            self.thread.join()


PRESETS = {
    "1": {
        "title": "아이디어 뱅크 (혁신가)",
        "desc": "창의적이고 혁신적인 아이디어를 계속 제시하지만 세부 실행 계획이나 현실적인 리스크는 간과하는 경향이 있음. 말투는 열정적이고 하이텐션임.",
        "prompt": "당신은 항상 새롭고 혁신적인 아이디어를 던지는 '아이디어 뱅크' 성향입니다. 기술적 제약이나 일정보다는 사용자 경험(UX)과 기발함에 초점을 맞춥니다. 리스크는 일단 시도해 본 다음 해결하자고 주장합니다. 말투는 열정적이며 느낌표와 긍정적인 표현을 자주 사용합니다."
    },
    "2": {
        "title": "리스크 분석가 (현실주의자 / 레드팀)",
        "desc": "매우 꼼꼼하고 현실적이며 예산, 일정, 기술적 리스크를 먼저 분석하여 안정성을 추구함. 말투는 이성적이고 차분함.",
        "prompt": "당신은 극도로 현실적이고 꼼꼼한 '리스크 분석가'이자 레드팀 성향입니다. 어떤 아이디어가 나오면 일정, 예산, 기술적 한계, 리소스 낭비 등의 관점에서 현실적인 문제점을 냉철하게 지적합니다. 감정에 휩쓸리지 않고 논리적인 수치와 팩트 위주로 차분하고 딱딱하게 말합니다."
    },
    "3": {
        "title": "화합가 (조율 및 공감형)",
        "desc": "팀원 간 의견 대립을 중재하고 서로의 절충안을 찾으려 노력함. 부드럽고 긍정적인 말투로 팀 분위기를 해치지 않으려 함.",
        "prompt": "당신은 팀의 분위기와 화합을 중시하는 '화합가' 성향입니다. 대립하는 의견 사이에서 절충안을 찾아내려고 노력하며, 다른 사람의 발언에 공감을 잘 해줍니다. 상대방이 상처받지 않도록 완곡하고 따뜻한 말투를 사용하며 칭찬을 섞어서 의견을 냅니다."
    },
    "4": {
        "title": "실행 주의자 (실용가)",
        "desc": "구체적인 구현 계획과 실질적인 대안 마련에 집중함. 복잡한 아이디어보다 '당장 할 수 있는 것'을 선호하며 말투가 간결함.",
        "prompt": "당신은 말보다 행동을 중시하는 '실행 주의자' 성향입니다. 복잡하고 추상적인 이야기 대신 '누가 무엇을 언제까지 할 것인가'에 관심이 쏠려 있습니다. 최소 기능 제품(MVP) 중심의 빠른 실행을 선호하며, 발언이 군더더기 없이 짧고 핵심만 짚습니다."
    },
    "5": {
        "title": "불도저 리더 (추진력 리더)",
        "desc": "목표 지향적이며 팀원들을 강하게 압박하지만 마감 기한과 비즈니스 성과를 확실하게 챙김. 단호한 리더십을 보임.",
        "prompt": "당신은 목표 달성을 최우선으로 생각하는 '불도저 리더'입니다. 일의 속도와 완성도, 비즈니스 성과를 강하게 압박하며 마감 기한을 엄격히 준수하려 합니다. 추진력이 강하고 결단력이 있으며 어조가 단호하고 명확합니다."
    }
}

SAVED_PARTICIPANTS = [
    {"name": "김정준", "role": "업무 향상을 위한 역할",               "preset": "3"},
    {"name": "문경수", "role": "일처리 잘하고 적극적 의사 표명, 레드팀", "preset": "2"},
    {"name": "이인선", "role": "실행능력이 좋고 여성",                 "preset": "4"},
    {"name": "배재환", "role": "긍정적 소통가",                       "preset": "3"},
    {"name": "박범서", "role": "부정적 시각과 게으름",
     "preset": "6", "custom_desc": "매사에 귀찮아하고 부정적이며 냉소적이고 적극적으로 일하지 않으려는 성향"},
]

COLORS = [Fore.CYAN, Fore.GREEN, Fore.YELLOW, Fore.MAGENTA, Fore.BLUE]


@dataclass
class MeetingState:
    """회의 진행 상태 — 의제 위치, 제약 조건, 결정 원장을 단일 객체로 관리."""
    topic: str
    constraints: dict
    agenda: list
    current_phase: int = 0
    ledger: dict = None

    def __post_init__(self):
        if self.ledger is None:
            self.ledger = {
                "decisions": [],
                "open_questions": [],
                "action_items": []
            }

    def constraints_str(self):
        if not self.constraints:
            return "없음"
        return "\n".join(f"  - {k}: {v}" for k, v in self.constraints.items())

    def ledger_str(self):
        d = self.ledger
        parts = []
        if d["decisions"]:
            parts.append("▸ 결정: " + " / ".join(d["decisions"]))
        if d["open_questions"]:
            parts.append("▸ 미결: " + " / ".join(d["open_questions"]))
        if d["action_items"]:
            parts.append("▸ 액션: " + " / ".join(d["action_items"]))
        return "\n".join(parts) if parts else "아직 없음"

    def current_agenda_str(self):
        if self.current_phase < len(self.agenda):
            return self.agenda[self.current_phase]
        return "최종 정리 단계"


# dataclass import 에러에 대비해 수동으로 흉내 내기 (만약 호환성 문제 발생 시 대비)
try:
    from dataclasses import dataclass, field
except ImportError:
    # 데코레이터 모방
    def dataclass(cls):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        cls.__init__ = __init__
        return cls
    field = lambda **kwargs: None


class Participant:
    def __init__(self, name, role, is_leader, preset_key=None, custom_desc=None):
        self.name = name
        self.role = role
        self.is_leader = is_leader
        self.color = Fore.WHITE

        if preset_key and preset_key in PRESETS:
            self.persona_desc = PRESETS[preset_key]["desc"]
            self.persona_prompt = PRESETS[preset_key]["prompt"]
        else:
            self.persona_desc = custom_desc or "평범하고 조용한 업무 성향"
            self.persona_prompt = f"당신은 다음과 같은 특징을 가진 팀원입니다: {custom_desc}"

    def get_system_instruction(self, all_participants, meeting_state):
        member_list = "\n".join(
            f"- {p.name} ({p.role}): {p.persona_desc}" for p in all_participants
        )

        chemistry_rules = """
[팀 내 대화 케미 가이드]
- '김정준' 팀장은 온화하게 모든 의견을 존중하며 갈등을 봉합하려 애씁니다.
- '문경수' 팀원은 리스크가 높은 의견을 내는 팀원들의 말에 예산과 현실적 타격을 논리적으로 집요하게 찌릅니다.
- '이인선' 팀원은 계획만 늘어놓는 문경수나 박범서의 소극적인 태도에 '일단 실행부터 하자'며 실질적 대안을 단차게 제안합니다.
- '배재환' 팀원은 문경수가 날카롭게 지적하더라도 그의 꼼꼼함을 칭찬하고 리액션을 보내며 부드럽게 대화를 이어갑니다.
- '박범서' 팀원은 매사 귀찮아하고 시큰둥하므로 "어차피 안 될 거 일만 늘어난다", "대충 기존 거 베끼면 안 되나" 같은 귀찮음 섞인 피드백을 짧고 툭툭 던지듯이 냅니다.
"""

        total = len(meeting_state.agenda)
        current = meeting_state.current_phase
        agenda_context = f"""
[현재 회의 진행 상태]
▶ 현재 의제 ({current + 1}/{total}): {meeting_state.current_agenda_str()}
▶ 남은 의제: {', '.join(meeting_state.agenda[current + 1:]) if current + 1 < total else '없음'}
▶ 제약 조건:
{meeting_state.constraints_str()}
▶ 지금까지 결정/합의된 사항:
{meeting_state.ledger_str()}
"""

        instruction = f"""당신은 가상 팀 회의에 참여하는 인물 시뮬레이터입니다.
이름: {self.name}
역할: {self.role} (팀장 여부: {self.is_leader})
성격: {self.persona_prompt}

회의 주제: {meeting_state.topic}
참가자:
{member_list}
{chemistry_rules}
{agenda_context}
[발언 지침]
1. 캐릭터 성격·말투·가치관을 연극 배우처럼 극도로 유지하세요.
2. **현재 의제에 집중**하여 발언하세요. 의제 범위를 벗어나면 팀장이 제지합니다.
3. 제약 조건(예산, 기한 등)을 실제 논거로 활용하세요. 근거 없이 수치를 지어내지 마세요.
4. '회의 관찰자(사용자)' 개입 시 즉시 캐릭터 스타일로 응답하세요.
5. 3~4문장 이내 구어체로 말하세요.
6. 이름 말머리 금지 — 대사만 출력.
7. 마지막 줄에 반드시 태그: `[TARGET: 이름]` / `[TARGET: None]` / `[TARGET: 회의록작성]`
"""
        if self.is_leader:
            instruction += "\n8. 팀장으로서 현재 의제가 충분히 논의됐다고 판단되면 결론을 정리하고 다음 의제로 자연스럽게 넘어가세요."
        return instruction


# 2. 통합 LLM API 호출 구현 (REST API Direct Call - 무의존성)
def call_llm(provider, model, prompt, system_instruction=None, temperature=0.75, api_key=None, api_url=None):
    """
    urllib를 사용하여 Gemini API 또는 OpenAI 호환 로컬 API(Ollama, LM Studio 등)를 호출하는 통합 함수.
    """
    if provider == "gemini":
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
        
        # API 페이로드 구성
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "temperature": temperature
            }
        }
        if system_instruction:
            payload["systemInstruction"] = {
                "parts": [{"text": system_instruction}]
            }
            
        req = urllib.request.Request(
            url, 
            data=json.dumps(payload).encode('utf-8'), 
            headers={"Content-Type": "application/json"}
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                res_data = json.loads(response.read().decode('utf-8'))
                return res_data['candidates'][0]['content']['parts'][0]['text'].strip()
        except Exception as e:
            raise RuntimeError(f"Gemini API 호출 오류 ({model}): {e}")

    else:
        # 로컬 LLM (Ollama, LM Studio 등) 호출
        # api_url은 'http://localhost:11434/v1/chat/completions' 포맷이어야 함
        messages = []
        if system_instruction:
            messages.append({"role": "system", "content": system_instruction})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature
        }
        
        req = urllib.request.Request(
            api_url,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Content-Type": "application/json"}
        )
        try:
            with urllib.request.urlopen(req, timeout=45) as response:
                res_data = json.loads(response.read().decode('utf-8'))
                return res_data['choices'][0]['message']['content'].strip()
        except Exception as e:
            raise RuntimeError(f"로컬 LLM 호출 오류 (모델: {model}, URL: {api_url}): {e}")


def configure_llm():
    """사용할 LLM 공급자와 모델을 CLI 환경에서 설정합니다."""
    if not HAS_COLORAMA:
        print("💡 팁: 'pip install colorama'를 실행하시면 콘솔창에서 화려한 색상을 볼 수 있습니다.")

    print(Fore.CYAN + Style.BRIGHT + "==================================================")
    print(Fore.CYAN + Style.BRIGHT + "            LLM 모델 및 연결 구성 설정             ")
    print(Fore.CYAN + Style.BRIGHT + "==================================================")
    print("1. Gemini API (클라우드, 기본값)")
    print("2. Ollama (로컬, http://localhost:11434)")
    print("3. LM Studio / OpenAI 호환 API (로컬, http://localhost:1234/v1)")
    
    choice = input("\n선택 (1-3, 기본값 1): ").strip()
    if not choice:
        choice = "1"
        
    provider = "gemini"
    model = "gemini-2.5-flash"
    api_key = None
    api_url = None
    
    if choice == "1":
        provider = "gemini"
        api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            print(Fore.YELLOW + "\nGEMINI_API_KEY / GOOGLE_API_KEY 환경 변수를 찾을 수 없습니다.")
            api_key = input("Gemini API Key를 입력하세요: ").strip()
            if not api_key:
                print(Fore.RED + "오류: API Key가 입력되지 않아 종료합니다.")
                sys.exit(1)
        model = "gemini-2.5-flash"
        
    elif choice == "2":
        provider = "local_ollama"
        api_url = "http://localhost:11434/v1/chat/completions"
        print(f"\nOllama 기본 API URL: {api_url}")
        custom_url = input("포트나 주소를 변경하시겠습니까? (엔터 입력 시 기본값 사용): ").strip()
        if custom_url:
            # API 엔드포인트 누락 대비 보정
            if not custom_url.endswith("/v1/chat/completions"):
                if custom_url.endswith("/"):
                    custom_url += "v1/chat/completions"
                else:
                    custom_url += "/v1/chat/completions"
            api_url = custom_url
        
        model = input("사용할 Ollama 모델명을 입력하세요 (예: llama3, gemma2, qwen2.5) [기본값: llama3]: ").strip()
        if not model:
            model = "llama3"
            
    elif choice == "3":
        provider = "local_openai"
        api_url = "http://localhost:1234/v1/chat/completions"
        print(f"\nOpenAI 호환 API 기본 URL: {api_url}")
        custom_url = input("포트나 주소를 변경하시겠습니까? (엔터 입력 시 기본값 사용): ").strip()
        if custom_url:
            if not custom_url.endswith("/v1/chat/completions"):
                if custom_url.endswith("/"):
                    custom_url += "v1/chat/completions"
                else:
                    custom_url += "/v1/chat/completions"
            api_url = custom_url
            
        model = input("사용할 로컬 모델명을 입력하세요 (LM Studio 등에 로드된 모델명) [기본값: local-model]: ").strip()
        if not model:
            model = "local-model"
            
    else:
        print(Fore.RED + "\n잘못된 선택입니다. Gemini API 모드로 시작합니다.")
        provider = "gemini"
        api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            api_key = input("Gemini API Key: ").strip()
            if not api_key:
                sys.exit(1)
        model = "gemini-2.5-flash"
        
    return {
        "provider": provider,
        "model": model,
        "api_key": api_key,
        "api_url": api_url
    }


def get_constraints_input():
    """회의 전 팩트 기반 제약 조건을 수집합니다."""
    print(Style.BRIGHT + "\n=== 회의 사전 조건 입력 (없으면 Enter 건너뛰기) ===")
    budget   = input("예산/자원 제약: ").strip()
    deadline = input("마감 기한: ").strip()
    notes    = input("기타 (기존 결정, 금지 사항, 배경 등): ").strip()
    constraints = {}
    if budget:   constraints["예산/자원"] = budget
    if deadline: constraints["기한"]     = deadline
    if notes:    constraints["기타"]     = notes
    return constraints


def generate_agenda(llm_config, topic, constraints):
    """주제를 3~4개의 소의제로 분해합니다."""
    c_str = "\n".join(f"- {k}: {v}" for k, v in constraints.items()) if constraints else "없음"
    prompt = f"""회의 주제를 3~4개의 소의제로 분해하세요.

주제: {topic}
제약: {c_str}

규칙:
- 각 소의제는 '~를 어떻게 할 것인가?' 형태의 구체적 질문
- 순서: 현황/목표 파악 → 전략/방향 → 실행 계획 → (필요시) 리스크 대응
- JSON 배열만 출력: ["소의제1", "소의제2", ...]
- 한국어"""

    try:
        response_text = call_llm(
            provider=llm_config["provider"],
            model=llm_config["model"],
            prompt=prompt,
            api_key=llm_config["api_key"],
            api_url=llm_config["api_url"]
        )
        match = re.search(r'\[.*\]', response_text.strip(), re.DOTALL)
        if match:
            return [str(a) for a in json.loads(match.group())[:4]]
    except Exception as e:
        print(Fore.YELLOW + f"\n의제 자동 생성 실패 ({e}), 기본 의제를 사용합니다.")
    return [
        f"{topic}의 현황과 목표를 어떻게 정의할 것인가?",
        f"{topic}의 핵심 전략을 어떻게 결정할 것인가?",
        f"실행 계획과 역할 분담을 어떻게 할 것인가?",
    ]


def update_ledger(llm_config, meeting_state, conversation_history, phase_topic):
    """의제 완료 후 대화에서 결정 사항을 추출해 원장을 갱신합니다."""
    recent = "\n".join(conversation_history[-15:])
    prompt = f"""회의 대화에서 결정 사항을 추출하세요.

완료된 의제: {phase_topic}
대화 (최근):
{recent}

기존 원장:
- 결정: {meeting_state.ledger["decisions"]}
- 미결: {meeting_state.ledger["open_questions"]}
- 액션: {meeting_state.ledger["action_items"]}

JSON만 출력 (대화에서 실제 언급된 것만, 없으면 빈 리스트):
{{"decisions": [], "open_questions": [], "action_items": []}}

주의: 대화에서 명시적으로 합의/언급된 내용만 포함하세요. 추정하거나 지어내지 마세요."""

    try:
        response_text = call_llm(
            provider=llm_config["provider"],
            model=llm_config["model"],
            prompt=prompt,
            api_key=llm_config["api_key"],
            api_url=llm_config["api_url"]
        )
        match = re.search(r'\{.*\}', response_text.strip(), re.DOTALL)
        if match:
            updates = json.loads(match.group())
            for key in ["decisions", "open_questions", "action_items"]:
                existing = set(meeting_state.ledger[key])
                meeting_state.ledger[key].extend(x for x in updates.get(key, []) if x not in existing)
    except Exception as e:
        print(Fore.YELLOW + f"원장 업데이트 실패: {e}")


def wait_for_interrupt(delay=2.0):
    """자동 진행 중 Enter를 감지하면 개입 모드로 전환합니다."""
    print(Fore.WHITE + Style.DIM + "  [자동 진행 중... Enter 누르면 개입]", end="\r", flush=True)
    if HAS_MSVCRT:
        start = time.time()
        while time.time() - start < delay:
            if msvcrt.kbhit():
                key = msvcrt.getwch()
                if key in ('\r', '\n'):
                    sys.stdout.write("\r" + " " * 55 + "\r")
                    sys.stdout.flush()
                    return True
            time.sleep(0.05)
    else:
        # macOS / Linux 환경 또는 msvcrt가 없을 경우 select.select 활용 백업
        try:
            import select
            rlist, _, _ = select.select([sys.stdin], [], [], delay)
            if rlist:
                sys.stdin.readline()  # 엔터 키 소비
                sys.stdout.write("\r" + " " * 55 + "\r")
                sys.stdout.flush()
                return True
        except Exception:
            # 기타 환경 대비 단순 대기
            time.sleep(delay)
            
    sys.stdout.write("\r" + " " * 55 + "\r")
    sys.stdout.flush()
    return False


def main():
    print(Fore.CYAN + Style.BRIGHT + "==================================================")
    print(Fore.CYAN + Style.BRIGHT + "    가상 팀 회의 시뮬레이터 v2 (무의존성 & 로컬)   ")
    print(Fore.CYAN + Style.BRIGHT + "==================================================")

    # 1. 모델 설정 구성
    llm_config = configure_llm()

    # 참가자 로드
    participants = []
    for i, p_data in enumerate(SAVED_PARTICIPANTS):
        is_leader = (i == 0)
        if p_data["preset"] == "6":
            p = Participant(p_data["name"], p_data["role"], is_leader=is_leader,
                            custom_desc=p_data["custom_desc"])
        else:
            p = Participant(p_data["name"], p_data["role"], is_leader=is_leader,
                            preset_key=p_data["preset"])
        p.color = COLORS[i]
        participants.append(p)
    leader = participants[0]

    # 사전 조건 입력
    constraints = get_constraints_input()

    # 주제 입력
    print(Style.BRIGHT + "\n==============================================")
    topic = input("토론 회의 주제:\n> ").strip()
    if not topic:
        topic = "팀 생산성 향상을 위한 협업 툴 도입 전략 수립"
        print(Fore.YELLOW + f"기본 주제: '{topic}'")

    # 의제 자동 생성
    spinner = Spinner("회의 의제 자동 구성 중...")
    spinner.start()
    agenda = generate_agenda(llm_config, topic, constraints)
    spinner.stop()

    meeting_state = MeetingState(topic=topic, constraints=constraints, agenda=agenda)

    print(Fore.CYAN + Style.BRIGHT + "\n[오늘의 회의 의제]")
    for i, item in enumerate(agenda):
        print(Fore.CYAN + f"  {i + 1}. {item}")
    print(Fore.YELLOW + "\n💡 Enter → 대화 진행 / 텍스트 입력 → 관찰자로 개입")
    print(Fore.WHITE + "──────────────────────────────────────────────")

    conversation_history = []
    speaker_history = []

    # ── 헬퍼 함수 ──────────────────────────────────────────

    def get_next_speaker_fallback(current_name):
        last_spoken = {p.name: -1 for p in participants}
        for idx, msg in enumerate(conversation_history):
            for p in participants:
                if msg.startswith(f"{p.name} ("):
                    last_spoken[p.name] = idx
        candidates = sorted(
            [p for p in participants if p.name != current_name],
            key=lambda p: last_spoken[p.name]
        )
        return candidates[0].name

    def parse_target(text):
        match = re.search(r"\[TARGET:\s*([^\]]+)\]", text)
        if match:
            return match.group(1).strip(), text.replace(match.group(0), "").strip()
        return "None", text

    def print_speech(person, text):
        print(person.color + f"\n{person.name} ({person.role}):")
        print(f"\"{text}\"")

    def generate_reply(active_person):
        system_instruction = active_person.get_system_instruction(participants, meeting_state)
        history_str = "\n".join(conversation_history)
        prompt = (
            f"회의 기록:\n{history_str}\n\n"
            f"{active_person.name}의 차례입니다. "
            f"현재 의제 '{meeting_state.current_agenda_str()}'에 집중해 캐릭터로 발언하고 "
            f"마지막 줄에 TARGET 태그를 붙이세요."
        )

        # 사용자 개입 강제 반응
        if conversation_history and conversation_history[-1].startswith("회의 관찰자 (사용자):"):
            user_msg = conversation_history[-1].split(":", 1)[1].strip()
            prompt += (
                f"\n\n[★ 사용자 개입]\n\"{user_msg}\"\n"
                f"{active_person.name}은 이 말에 캐릭터 스타일로 먼저 반응한 후 회의를 이어가세요."
            )

        sp = Spinner(f"{active_person.name} 생각 중...")
        sp.start()
        reply = None
        last_error = None
        
        # Gemini 모델일 경우 1.5-flash로 자동 대체 시도
        models_to_try = [llm_config["model"], "gemini-1.5-flash"] if llm_config["provider"] == "gemini" else [llm_config["model"]]
        
        for m in models_to_try:
            for attempt in range(3):
                try:
                    reply = call_llm(
                        provider=llm_config["provider"],
                        model=m,
                        prompt=prompt,
                        system_instruction=system_instruction,
                        temperature=0.75,
                        api_key=llm_config["api_key"],
                        api_url=llm_config["api_url"]
                    )
                    break
                except Exception as e:
                    last_error = e
                    if any(k in str(e) for k in ["503", "quota", "limit"]):
                        time.sleep(2 * (attempt + 1))
                    else:
                        time.sleep(1)
            if reply:
                break
        sp.stop()

        if not reply:
            reply = f"잠시 마이크 문제가... (오류: {last_error}) [TARGET: {leader.name}]"
        return reply.replace("[NEXT:", "[TARGET:")

    # ── 팀장 오프닝 ────────────────────────────────────────

    print(Fore.RED + Style.BRIGHT + f"\n[회의 개시] 주제: {topic}\n")
    opening = generate_reply(leader)
    target_val, clean = parse_target(opening)
    conversation_history.append(f"{leader.name} ({leader.role}): {clean}")
    print_speech(leader, clean)

    next_speaker_name = (
        target_val
        if target_val in [p.name for p in participants] and target_val != leader.name
        else get_next_speaker_fallback(leader.name)
    )
    print(Fore.WHITE + Style.DIM + f"─── (다음: {next_speaker_name})")

    # ── 의제별 루프 ────────────────────────────────────────

    finished_early = False

    for phase_idx, phase_topic in enumerate(agenda):
        if finished_early:
            break
        meeting_state.current_phase = phase_idx

        print(Fore.CYAN + Style.BRIGHT +
              f"\n━━━ 의제 {phase_idx + 1}/{len(agenda)}: {phase_topic} ━━━")

        # 팀장 의제 전환 멘트 (첫 의제 제외)
        if phase_idx > 0:
            trans = generate_reply(leader)
            t_val, t_clean = parse_target(trans)
            conversation_history.append(f"{leader.name} ({leader.role}): {t_clean}")
            print_speech(leader, t_clean)
            next_speaker_name = (
                t_val
                if t_val in [p.name for p in participants] and t_val != leader.name
                else get_next_speaker_fallback(leader.name)
            )
            print(Fore.WHITE + Style.DIM + f"─── (다음: {next_speaker_name})")

        phase_turns = 0
        max_phase_turns = 6

        while phase_turns < max_phase_turns:
            interrupted = wait_for_interrupt(delay=2.0)
            if interrupted:
                user_input = input(Fore.WHITE + Style.BRIGHT + "💬 개입 내용: ").strip()
            else:
                user_input = ""

            if user_input:
                conversation_history.append(f"회의 관찰자 (사용자): {user_input}")
                print(Fore.WHITE + Style.BRIGHT + f"\n💬 관찰자 (사용자): \"{user_input}\"")
                print(Fore.WHITE + Style.DIM + "───────────────────────────────")

                # 이름 언급 → 강제 지목
                for p in participants:
                    short = p.name[1:] if len(p.name) >= 3 else p.name
                    if p.name in user_input or short in user_input:
                        next_speaker_name = p.name
                        print(Fore.YELLOW + f"📌 발언권 → '{p.name}'")
                        break
                else:
                    # 직전 발언자에게 반응 기회
                    for msg in reversed(conversation_history[:-1]):
                        for p in participants:
                            if msg.startswith(f"{p.name} ("):
                                next_speaker_name = p.name
                                break
                        else:
                            continue
                        break

            active_person = next((p for p in participants if p.name == next_speaker_name), None)
            if next_speaker_name == "회의록작성" or not active_person:
                finished_early = True
                break

            reply_content = generate_reply(active_person)
            target_val, clean = parse_target(reply_content)
            conversation_history.append(f"{active_person.name} ({active_person.role}): {clean}")
            print_speech(active_person, clean)

            speaker_history.append(active_person.name)
            is_loop = len(speaker_history) >= 4 and len(set(speaker_history[-4:])) <= 2

            if target_val == "회의록작성":
                next_speaker_name = "회의록작성"
                finished_early = True
            elif not is_loop and target_val in [p.name for p in participants] and target_val != active_person.name:
                next_speaker_name = target_val
            else:
                next_speaker_name = get_next_speaker_fallback(active_person.name)
                if is_loop:
                    print(Fore.YELLOW + f"📌 독점 감지 → '{next_speaker_name}'에게 위임")

            print(Fore.WHITE + Style.DIM + f"─── (다음: {next_speaker_name})")
            phase_turns += 1

        # 의제 완료 → 원장 업데이트
        sp = Spinner(f"의제 {phase_idx + 1} 결정사항 추출 중...")
        sp.start()
        update_ledger(llm_config, meeting_state, conversation_history, phase_topic)
        sp.stop()

        d = meeting_state.ledger
        print(Fore.CYAN + f"\n[의제 {phase_idx + 1} 완료 — 원장 업데이트]")
        if d["decisions"]:
            print(Fore.GREEN  + "  결정: " + " / ".join(d["decisions"][-3:]))
        if d["open_questions"]:
            print(Fore.YELLOW + "  미결: " + " / ".join(d["open_questions"][-3:]))
        if d["action_items"]:
            print(Fore.BLUE   + "  액션: " + " / ".join(d["action_items"][-3:]))

        if finished_early:
            break

    # ── 최종 회의록 (원장 기반) ────────────────────────────

    print(Fore.WHITE + Style.DIM +
          f"\n* 팀장 {leader.name}님이 원장 기반 최종 회의록을 작성합니다.")

    ledger = meeting_state.ledger
    ledger_text = f"""결정 사항 ({len(ledger['decisions'])}건):
{chr(10).join('  - ' + d for d in ledger['decisions']) or '  없음'}

미결 이슈 ({len(ledger['open_questions'])}건):
{chr(10).join('  - ' + q for q in ledger['open_questions']) or '  없음'}

액션 아이템 ({len(ledger['action_items'])}건):
{chr(10).join('  - ' + a for a in ledger['action_items']) or '  없음'}""".strip()

    summary_prompt = f"""팀장으로서 회의 클로징 멘트와 함께 아래 원장을 바탕으로 공식 회의록을 작성하세요.

[결정 원장 — 유일한 신뢰 출처]
{ledger_text}

주의: 원장에 없는 내용(날짜, 담당자, 수치)을 임의로 추가하지 마세요.
원장에 명시된 내용만 회의록에 포함하세요."""

    sp = Spinner(f"{leader.name} 최종 회의록 작성 중...")
    sp.start()
    try:
        final_summary = call_llm(
            provider=llm_config["provider"],
            model=llm_config["model"],
            prompt=summary_prompt,
            system_instruction=leader.get_system_instruction(participants, meeting_state),
            api_key=llm_config["api_key"],
            api_url=llm_config["api_url"]
        )
    except Exception as e:
        final_summary = f"회의록 작성 오류: {e}"
    finally:
        sp.stop()

    print(leader.color + f"\n{leader.name} ({leader.role}) - 최종 요약 및 회의록:")
    print(Fore.CYAN + "==============================================")
    print(final_summary)
    print(Fore.CYAN + "==============================================")

    output_file = "meeting_minutes.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"회의 주제: {topic}\n")
        f.write(f"의제: {' / '.join(agenda)}\n")
        f.write(f"제약 조건:\n{meeting_state.constraints_str()}\n")
        f.write("=" * 40 + "\n\n")
        f.write("## [회의 대화록]\n")
        f.write("\n".join(conversation_history))
        f.write("\n\n" + "=" * 40 + "\n\n")
        f.write("## [결정 원장]\n")
        f.write(ledger_text)
        f.write("\n\n" + "=" * 40 + "\n\n")
        f.write("## [최종 회의록]\n")
        f.write(final_summary)
    print(Fore.GREEN + f"\n회의록이 '{output_file}'에 저장되었습니다.")


if __name__ == "__main__":
    main()
