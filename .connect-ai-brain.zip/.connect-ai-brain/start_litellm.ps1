# LiteLLM Auto-start Script
# Waits for network, then starts LiteLLM proxy on port 8000

Start-Sleep -Seconds 10

$logPath = "$env:USERPROFILE\.connect-ai-brain\litellm.log"
$configPath = "$env:USERPROFILE\.connect-ai-brain\litellm_config.yaml"

"[$(Get-Date)] LiteLLM starting..." | Out-File $logPath -Append -Encoding UTF8

try {
    python "$env:USERPROFILE\.connect-ai-brain\proxy.py" 2>&1 | Out-File $logPath -Append -Encoding UTF8
} catch {
    "[$(Get-Date)] ERROR: $_" | Out-File $logPath -Append -Encoding UTF8
}
