"""
Google Calendar OAuth 토큰 발급 스크립트
실행하면 브라우저가 열립니다 — Google 계정으로 로그인 후 허용 클릭
"""
import json, os
from google_auth_oauthlib.flow import InstalledAppFlow

CLIENT_ID     = "686191171962-coqf57hpg3dfdt9kr04dj1426p7l2eqv.apps.googleusercontent.com"
CLIENT_SECRET = "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"
SCOPES        = ["https://www.googleapis.com/auth/calendar"]

CONFIG = {
    "installed": {
        "client_id":     CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "redirect_uris": ["urn:ietf:wg:oauth:2.0:oob", "http://localhost"],
        "auth_uri":      "https://accounts.google.com/o/oauth2/auth",
        "token_uri":     "https://oauth2.googleapis.com/token",
    }
}

TARGET = os.path.join(
    os.path.expanduser("~"),
    ".connect-ai-brain", "_company", "_agents", "secretary", "tools",
    "google_calendar_write.json"
)

flow = InstalledAppFlow.from_client_config(CONFIG, SCOPES)
creds = flow.run_local_server(port=5814)

with open(TARGET, "r", encoding="utf-8") as f:
    data = json.load(f)

data["CLIENT_ID"]     = CLIENT_ID
data["CLIENT_SECRET"] = CLIENT_SECRET
data["REFRESH_TOKEN"] = creds.refresh_token

with open(TARGET, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print("\n✅ 완료! google_calendar_write.json에 토큰 저장됨")
print(f"   REFRESH_TOKEN: {creds.refresh_token[:30]}...")
