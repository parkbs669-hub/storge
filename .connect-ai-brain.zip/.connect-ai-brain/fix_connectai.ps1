# Connect AI 복구 스크립트 — LM Studio 서버 충돌 해제 + proxy.py 재시작 + Task Scheduler 등록

Write-Host "=== Connect AI 복구 시작 ===" -ForegroundColor Cyan

# 1. 포트 1234 점유 프로세스 확인 및 종료 (LM Studio 서버 프로세스만 종료)
$portProcess = Get-NetTCPConnection -LocalPort 1234 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($portProcess) {
    $pid1234 = $portProcess.OwningProcess
    $proc = Get-Process -Id $pid1234 -ErrorAction SilentlyContinue
    if ($proc) {
        Write-Host "포트 1234 점유 프로세스: $($proc.ProcessName) (PID: $pid1234)" -ForegroundColor Yellow
        if ($proc.ProcessName -like "*LM Studio*" -or $proc.ProcessName -eq "node") {
            # LM Studio 서버 프로세스인 경우에만 종료
            Write-Host "LM Studio 서버 프로세스 종료 중..." -ForegroundColor Yellow
            Stop-Process -Id $pid1234 -Force
            Start-Sleep -Seconds 2
            Write-Host "완료." -ForegroundColor Green
        } elseif ($proc.ProcessName -eq "python" -or $proc.ProcessName -eq "pythonw") {
            Write-Host "proxy.py가 이미 실행 중입니다. 재시작합니다..." -ForegroundColor Yellow
            Stop-Process -Id $pid1234 -Force
            Start-Sleep -Seconds 2
        } else {
            Write-Host "알 수 없는 프로세스가 포트를 점유 중: $($proc.ProcessName)" -ForegroundColor Red
            Write-Host "수동으로 확인 후 종료하세요."
            exit 1
        }
    }
}

# 2. proxy.py 백그라운드 시작
$proxyPath = "$env:USERPROFILE\.connect-ai-brain\proxy.py"
if (-not (Test-Path $proxyPath)) {
    Write-Host "proxy.py 파일이 없습니다: $proxyPath" -ForegroundColor Red
    exit 1
}

Write-Host "proxy.py 시작 중..." -ForegroundColor Cyan
Start-Process -FilePath "python" -ArgumentList $proxyPath -WindowStyle Hidden
Start-Sleep -Seconds 3

# 시작 확인
$check = Get-NetTCPConnection -LocalPort 1234 -ErrorAction SilentlyContinue
if ($check) {
    Write-Host "proxy.py 시작 완료. 포트 1234 정상 수신 중." -ForegroundColor Green
} else {
    Write-Host "proxy.py 시작 실패. 수동으로 확인하세요." -ForegroundColor Red
}

# 3. Task Scheduler 등록 (관리자 권한 필요)
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($isAdmin) {
    Write-Host "Task Scheduler 등록 중..." -ForegroundColor Cyan

    $scriptPath = "$env:USERPROFILE\.connect-ai-brain\start_litellm.ps1"
    $action  = New-ScheduledTaskAction -Execute "powershell.exe" `
               -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$scriptPath`""
    $trigger = New-ScheduledTaskTrigger -AtLogOn
    $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 0) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName "ConnectAI-LiteLLM" -Action $action -Trigger $trigger -Settings $settings -RunLevel Highest -Force | Out-Null

    Write-Host "Task Scheduler 등록 완료 (다음 로그인부터 자동 시작)." -ForegroundColor Green
} else {
    Write-Host "관리자 권한 없음 — Task Scheduler 등록 건너뜀." -ForegroundColor Yellow
    Write-Host "관리자 PowerShell에서 이 스크립트를 다시 실행하면 자동 시작이 등록됩니다." -ForegroundColor Yellow
}

# 4. 연결 테스트
Write-Host "`nConnect AI 연결 테스트..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "http://127.0.0.1:1234/v1/models" -TimeoutSec 5
    $models = $response.data | ForEach-Object { $_.id }
    Write-Host "사용 가능한 모델: $($models -join ', ')" -ForegroundColor Green
    Write-Host "`n=== 복구 완료 ===" -ForegroundColor Green
    Write-Host "VS Code에서 Connect AI 사이드바 → 👔 버튼 클릭 후 사용하세요." -ForegroundColor Cyan
} catch {
    Write-Host "연결 테스트 실패: $_" -ForegroundColor Red
}

Write-Host "`n[LM Studio 충돌 방지] LM Studio > Local Server > 'Auto-start server on launch' 를 OFF로 설정하세요." -ForegroundColor Magenta
