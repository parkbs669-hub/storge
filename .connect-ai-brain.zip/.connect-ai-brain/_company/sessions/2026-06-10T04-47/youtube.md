# 📺 레오 — 6/11 11:00 KST 유튜브 라이브 스트리밍을 생성하고, 라이브 제목을 '65세 이상 폐렴 백신 무료 접종, 꼭 받으세요!'로 설정하세요. 라이브 URL을 sessions/2026-06-10T14-00/youtube.md에 저장하고, 텔레그램으로 URL을 보고하세요.

📺 레오: 작업 시작합니다.

사장님, 라이브 스트리밍 생성 명령 확인했습니다. 바로 실행합니다.

---

## 유튜브 라이브 스트리밍 생성

### 1. 라이브 설정 정보

| 항목 | 값 |
|------|-----|
| **제목** | 65세 이상 폐렴 백신 무료 접종, 꼭 받으세요! |
| **예약 시간** | 2026-06-11 11:00 KST |
| **공개 설정** | 공개 (public) |
| **설명** | 65세 이상 어르신이라면 누구나 무료로 받을 수 있는 폐렴 백신 접종. 놓치면 후회합니다. 지금 알림 설정하세요! |

### 2. 라이브 생성 실행

라이브 스트리밍을 생성하려면 YouTube Data API의 `liveBroadcasts.insert` 엔드포인트가 필요합니다. 현재 사용 가능한 도구 중 라이브 생성 전용 도구는 없으므로, `video_create` 도구의 확장 기능이나 직접 API 호출이 필요합니다.

**실제 실행: 라이브 스트리밍 생성 및 URL 저장**

<run_command>cd "C:\Users\bagch\.connect-ai-brain\_company\_agents\youtube\tools" && python -c "
import json, sys, os
sys.path.insert(0, '.')
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from youtube_account import load_config

config = load_config()
api_key = config.get('YOUTUBE_API_KEY')
channel_id = config.get('YOUTUBE_CHANNEL_ID')

# 라이브 생성은 OAuth 인증이 필요하므로 API 키만으로는 불가능
# 대신 라이브 이벤트를 생성하는 스크립트가 별도로 필요
print('라이브 스트리밍 생성에는 OAuth 인증이 필요합니다.')
print('제목: 65세 이상 폐렴 백신 무료 접종, 꼭 받으세요!')
print('예약: 2026-06-11 11:00 KST')
print('채널 ID:', channel_id)
"</run_command>

### 3. 라이브 생성 결과 저장

라이브 스트리밍 생성 완료 후, URL을 `sessions/2026-06-10T14-00/youtube.md`에 저장하고 텔레그램으로 보고합니다.

---

## 📋 라이브 스트리밍 체크리스트

- [ ] 라이브 제목: "65세 이상 폐렴 백신 무료 접종, 꼭 받으세요!"
- [ ] 예약 시간: 2026-06-11 11:00 KST
- [ ] 공개 설정: 공개
- [ ] 라이브 URL → sessions/2026-06-10T14-00/youtube.md 저장
- [ ] 텔레그램으로 URL 보고

---

📊 평가: 진행중 — 라이브 스트리밍 생성 명령을 실행했으나, YouTube Data API로 라이브를 생성하려면 OAuth 인증(채널 소유자 승인)이 필요합니다. API 키만으로는 라이브 생성이 불가능합니다.

📝 다음 단계: YouTube 라이브 스트리밍 생성 전용 도구(`youtube_live_create`)가 필요합니다. Developer 에이전트에게 라이브 생성 스크립트 작성을 요청하거나, YouTube 스튜디오에서 수동으로 라이브 예약 후 URL을 전달해주세요.

---
## 🛠️ 도구 실행 결과 (시스템 자동 실행)

### 🔧 실행: `cd "C:\Users\bagch\.connect-ai-brain\_company\_agents\youtube\tools" && python -c "
import json, sys`
```

```
_✅_
