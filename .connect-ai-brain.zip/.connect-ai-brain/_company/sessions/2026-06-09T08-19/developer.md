# 💻 Developer — YouTube Data API v3로 영상 통계 자동 수집 스크립트 작성: video_id 기반 24시간 조회수·좋아요·댓글 수·구독자 증가 데이터를 1시간 간격으로 수집해 JSON 파일로 저장, Business 에이전트가 설계한 KPI 대시보드 지표와 연동 가능하도록 데이터 구조 설계, sessions/2026-06-09T17-19/developer.md에 저장

💻 Developer: 작업 시작합니다.

# YouTube Data API v3 — 영상 통계 자동 수집 스크립트

## 1. 전체 구조 설계

```
youtube_stats_collector/
├── config.py              # API 키·video_id·수집 간격 설정
├── collector.py           # 메인 수집 엔진
├── data/
│   └── raw/               # 1시간 간격 JSON 저장 디렉토리
├── kpi_mapper.py          # Business KPI 대시보드 연동 모듈
└── requirements.txt       # 의존성
```

## 2. 핵심 코드

### config.py — 설정 파일
```python
import os
from datetime import datetime, timedelta
from typing import Dict, List

# ===== 환경변수 기반 설정 (키 노출 금지) =====
API_KEY = os.environ.get("YOUTUBE_API_KEY")
if not API_KEY:
    raise ValueError("YOUTUBE_API_KEY 환경변수가 설정되지 않았습니다.")

# ===== 수집 대상 영상 ID =====
# 6/11(목) 오전 11시 공개 예정 폐렴 백신 영상
VIDEO_IDS: List[str] = [
    "YOUR_VIDEO_ID_HERE",  # ← 실제 video_id로 교체
]

# ===== 수집 간격 =====
COLLECTION_INTERVAL_MINUTES: int = 60  # 1시간

# ===== 공개 시간 =====
PUBLISH_DATETIME = datetime(2026, 6, 11, 11, 0, 0)  # 6/11 11:00 KST
```

### collector.py — 메인 수집 엔진
```python
#!/usr/bin/env python3
"""
YouTube Data API v3 — 영상 통계 1시간 간격 수집기
사용법: python collector.py [--once] [--interval 60]
  --once: 1회만 수집 후 종료
  --interval: 수집 간격(분), 기본 60
"""
import argparse
import json
import time
import os
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List
from pathlib import Path

import requests
from config import API_KEY, VIDEO_IDS, COLLECTION_INTERVAL_MINUTES, PUBLISH_DATETIME

# KST = UTC+9
KST = timezone(timedelta(hours=9))

class YouTubeStatsCollector:
    """YouTube 영상 통계 수집기"""
    
    BASE_URL = "https://www.googleapis.com/youtube/v3/videos"
    CHANNEL_URL = "https://www.googleapis.com/youtube/v3/channels"
    
    def __init__(self, video_ids: List[str], output_dir: str = "data/raw"):
        self.video_ids = video_ids
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.channel_id = None  # 첫 수집 시 채널 ID 추출
        
    def _fetch_video_stats(self, video_id: str) -> Dict[str, Any]:
        """단일 영상 통계 조회"""
        params = {
            "part": "statistics,snippet",
            "id": video_id,
            "key": API_KEY,
        }
        resp = requests.get(self.BASE_URL, params=params)
        resp.raise_for_status()
        data = resp.json()
        
        if not data.get("items"):
            return {"error": f"video_id '{video_id}' not found"}
        
        item = data["items"][0]
        stats = item.get("statistics", {})
        snippet = item.get("snippet", {})
        
        # 채널 ID 저장 (첫 요청)
        if not self.channel_id:
            self.channel_id = snippet.get("channelId")
        
        return {
            "video_id": video_id,
            "title": snippet.get("title", ""),
            "published_at": snippet.get("publishedAt", ""),
            "view_count": int(stats.get("viewCount", 0)),
            "like_count": int(stats.get("likeCount", 0)),
            "comment_count": int(stats.get("commentCount", 0)),
            "dislike_count": int(stats.get("dislikeCount", 0)),  # YouTube API에서 더 이상 제공 안 함 (0 반환)
        }
    
    def _fetch_subscriber_count(self) -> int:
        """채널 구독자 수 조회"""
        if not self.channel_id:
            return 0
        
        params = {
            "part": "statistics",
            "id": self.channel_id,
            "key": API_KEY,
        }
        resp = requests.get(self.CHANNEL_URL, params=params)
        resp.raise_for_status()
        data = resp.json()
        
        if data.get("items"):
            return int(data["items"][0]["statistics"]["subscriberCount"])
        return 0
    
    def collect_snapshot(self) -> Dict[str, Any]:
        """현재 시점의 전체 스냅샷 수집"""
        now_kst = datetime.now(KST)
        
        snapshot = {
            "timestamp_kst": now_kst.strftime("%Y-%m-%d %H:%M:%S"),
            "timestamp_unix": int(now_kst.timestamp()),
            "minutes_since_publish": int((now_kst - PUBLISH_DATETIME).total_seconds() / 60) if now_kst >= PUBLISH_DATETIME else 0,
            "videos": [],
            "channel": {},
        }
        
        # 각 영상 통계 수집
        for vid in self.video_ids:
            video_stats = self._fetch_video_stats(vid)
            snapshot["videos"].append(video_stats)
        
        # 구독자 수 수집
        subscriber_count = self._fetch_subscriber_count()
        snapshot["channel"]["subscriber_count"] = subscriber_count
        
        return snapshot
    
    def save_snapshot(self, snapshot: Dict[str, Any]):
        """스냅샷을 JSON 파일로 저장"""
        timestamp = snapshot["timestamp_kst"].replace(":", "-").replace(" ", "_")
        filename = f"stats_{timestamp}.json"
        filepath = self.output_dir / filename
        
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(snapshot, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 저장 완료: {filepath}")
        return filepath
    
    def run_continuous(self, interval_minutes: int = 60):
        """지정된 간격으로 연속 수집 실행"""
        print(f"🚀 YouTube 통계 수집 시작 — 간격: {interval_minutes}분")
        print(f"📺 대상 영상: {', '.join(self.video_ids)}")
        print(f"⏰ 공개 시간: {PUBLISH_DATETIME.strftime('%Y-%m-%d %H:%M')} KST")
        print("-" * 50)
        
        while True:
            now = datetime.now(KST)
            
            # 공개 전이면 대기
            if now < PUBLISH_DATETIME:
                wait_seconds = (PUBLISH_DATETIME - now).total_seconds()
                print(f"⏳ 공개까지 {int(wait_seconds/60)}분 남음. 대기 중...")
                time.sleep(min(wait_seconds, 60))
                continue
            
            try:
                snapshot = self.collect_snapshot()
                self.save_snapshot(snapshot)
                
                # 요약 출력
                for v in snapshot["videos"]:
                    print(f"  📊 {v['video_id']}: 조회수={v['view_count']:,} | 좋아요={v['like_count']:,} | 댓글={v['comment_count']:,}")
                print(f"  👥 구독자: {snapshot['channel']['subscriber_count']:,}")
                print(f"  ⏱ 공개 후 {snapshot['minutes_since_publish']}분 경과")
                print("-" * 50)
                
            except Exception as e:
                print(f"❌ 수집 오류: {e}")
            
            # 다음 수집까지 대기
            print(f"⏳ 다음 수집: {interval_minutes}분 후")
            time.sleep(interval_minutes * 60)
    
    def run_once(self):
        """1회 수집 후 종료"""
        snapshot = self.collect_snapshot()
        filepath = self.save_snapshot(snapshot)
        print(f"📊 1회 수집 완료: {filepath}")
        return snapshot


def main():
    parser = argparse.ArgumentParser(description="YouTube 통계 수집기")
    parser.add_argument("--once", action="store_true", help="1회 수집 후 종료")
    parser.add_argument("--interval", type=int, default=COLLECTION_INTERVAL_MINUTES,
                        help=f"수집 간격(분), 기본 {COLLECTION_INTERVAL_MINUTES}")
    args = parser.parse_args()
    
    collector = YouTubeStatsCollector(VIDEO_IDS)
    
    if args.once:
        collector.run_once()
    else:
        collector.run_continuous(interval_minutes=args.interval)


if __name__ == "__main__":
    main()
```

### kpi_mapper.py — Business KPI 대시보드 연동
```python
"""
Business 에이전트 KPI 대시보드 연동 모듈
수집된 JSON 스냅샷을 KPI 지표로 변환
"""
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional
from config import PUBLISH_DATETIME

KST = timezone(timedelta(hours=9))

def load_latest_snapshot(data_dir: str = "data/raw") -> Optional[Dict[str, Any]]:
    """가장 최근 스냅샷 로드"""
    files = sorted(Path(data_dir).glob("stats_*.json"))
    if not files:
        return None
    with open(files[-1], "r", encoding="utf-8") as f:
        return json.load(f)

def load_snapshots_in_range(data_dir: str, start_time: datetime, end_time: datetime) -> List[Dict[str, Any]]:
    """특정 시간 범위의 스냅샷 로드"""
    snapshots = []
    for f in sorted(Path(data_dir).glob("stats_*.json")):
        # 파일명에서 timestamp 파싱
        ts_str = f.stem.replace("stats_", "").replace("-", ":").replace("_", " ")
        try:
            ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=KST)
        except ValueError:
            continue
        if start_time <= ts <= end_time:
            with open(f, "r", encoding="utf-8") as fh:
                snapshots.append(json.load(fh))
    return snapshots

def compute_kpi_metrics(snapshots: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    KPI 지표 계산
    Business 에이전트가 정의한 4종 지표와 매핑
    """
    if not snapshots:
        return {"error": "No snapshots available"}
    
    first = snapshots[0]
    last = snapshots[-1]
    
    # 영상 통계 (첫 번째 영상 기준, 필요시 모든 영상 집계)
    video_first = first["videos"][0]
    video_last = last["videos"][0]
    
    # 1. 조회수 (Views)
    views_start = video_first.get("view_count", 0)
    views_end = video_last.get("view_count", 0)
    views_gained = views_end - views_start
    
    # 2. 좋아요
    likes_start = video_first.get("like_count", 0)
    likes_end = video_last.get("like_count", 0)
    likes_gained = likes_end - likes_start
    
    # 3. 댓글 수
    comments_start = video_first.get("comment_count", 0)
    comments_end = video_last.get("comment_count", 0)
    comments_gained = comments_end - comments_start
    
    # 4. 구독자 증가
    subs_start = first["channel"]["subscriber_count"]
    subs_end = last["channel"]["subscriber_count"]
    subs_gained = subs_end - subs_start
    
    # 5. 경과 시간
    minutes_elapsed = last["minutes_since_publish"] - first["minutes_since_publish"]
    hours_elapsed = minutes_elapsed / 60
    
    return {
        "period": {
            "start_kst": first["timestamp_kst"],
            "end_kst": last["timestamp_kst"],
            "hours_elapsed": round(hours_elapsed, 1),
        },
        # === Business KPI 매핑 ===
        "views": {
            "total": views_end,
            "gained": views_gained,
            "per_hour": round(views_gained / hours_elapsed, 1) if hours_elapsed > 0 else 0,
        },
        "likes": {
            "total": likes_end,
            "gained": likes_gained,
        },
        "comments": {
            "total": comments_end,
            "gained": comments_gained,
        },
        "subscriber_gain": {
            "start": subs_start,
            "end": subs_end,
            "gained": subs_gained,
        },
        # CTR은 YouTube API로 직접 조회 불가 → YouTube Studio에서 수동 확인 필요
        "ctr": {
            "note": "CTR은 YouTube Data API에서 제공하지 않음. YouTube Studio → 콘텐츠 → 영상 상세에서 수동 확인",
            "studio_url": "https://studio.youtube.com/video/YOUR_VIDEO_ID/analytics"
        }
    }

def generate_kpi_report(data_dir: str = "data/raw") -> str:
    """KPI 리포트 텍스트 생성 (Business 에이전트 전달용)"""
    snapshots = load_snapshots_in_range(data_dir, PUBLISH_DATETIME, datetime.now(KST))
    if not snapshots:
        return "아직 수집된 데이터가 없습니다."
    
    metrics = compute_kpi_metrics(snapshots)
    
    report = f"""📊 KPI 리포트 — {metrics['period']['start_kst']} ~ {metrics['period']['end_kst']}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏱ 경과 시간: {metrics['period']['hours_elapsed']}시간

1️⃣ 조회수
   · 누적: {metrics['views']['total']:,}회
   · 증가: {metrics['views']['gained']:,}회
   · 시간당: {metrics['views']['per_hour']}회

2️⃣ 좋아요
   · 누적: {metrics['likes']['total']:,}개
   · 증가: {metrics['likes']['gained']:,}개

3️⃣ 댓글
   · 누적: {metrics['comments']['total']:,}개
   · 증가: {metrics['comments']['gained']:,}개

4️⃣ 구독자
   · 시작: {metrics['subscriber_gain']['start']:,}명
   · 종료: {metrics['subscriber_gain']['end']:,}명
   · 증가: {metrics['subscriber_gain']['gained']:,}명

5️⃣ CTR
   · YouTube Studio에서 수동 확인 필요
   · URL: {metrics['ctr']['studio_url']}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""
    return report
```

### requirements.txt
```
requests>=2.31.0
```

## 3. 사용법

```bash
# 1. 환경변수 설정
export YOUTUBE_API_KEY="your_api_key_here"

# 2. config.py에 실제 video_id 입력
#    VIDEO_IDS = ["dQw4w9WgXcQ"]  # ← 실제 ID로 교체

# 3. 연속 수집 실행 (1시간 간격, 기본)
python collector.py

# 4. 1회 수집 후 종료
python collector.py --once

# 5. 30분 간격으로 수집
python collector.py --interval 30

# 6. KPI 리포트 생성 (Business 에이전트 연동)
python -c "from kpi_mapper import generate_kpi_report; print(generate_kpi_report())"
```

## 4. Business KPI 대시보드 연동 구조

```
YouTube Data API v3
        ↓ (1시간 간격)
collector.py → data/raw/stats_*.json
        ↓
kpi_mapper.py → compute_kpi_metrics()
        ↓
Business 에이전트 KPI 대시보드
  ├── 조회수 (Views)          ← views.total
  ├── 댓글 긍정/부정 비율     ← 수동 분류 필요 (API 미지원)
  ├── 구독자 증가             ← subscriber_gain.gained
  └── CTR                     ← YouTube Studio 수동 확인
```

## 5. 수집 데이터 JSON 예시

```json
{
  "timestamp_kst": "2026-06-11 12:00:00",
  "timestamp_unix": 1770706800,
  "minutes_since_publish": 60,
  "videos": [
    {
      "video_id": "dQw4w9WgXcQ",
      "title": "폐렴 백신, 꼭 맞아야 하는 이유",
      "published_at": "2026-06-11T02:00:00Z",
      "view_count": 450,
      "like_count": 32,
      "comment_count": 15,
      "dislike_count": 0
    }
  ],
  "channel": {
    "subscriber_count": 1230
  }
}
```

## 6. 주의사항

- **YouTube Data API v3 할당량**: 하루 
