# 💻 Developer — 닥터프렌즈·건강한할매 협업 제안 회신 마감(6/10 18:00 KST) 기준으로 17:00 KST에 미회신 시 재독촉 알림을 자동 발송하는 스크립트를 작성하세요. 스크립트는 이메일 발송 API를 호출하거나 텔레그램 봇을 통해 사장님께 '17:00 KST — 닥터프렌즈·건강한할매 회신 없음, 재독촉 발송 필요' 메시지를 전송하도록 구성하고, sessions/2026-06-10T04-00/developer.md에 저장하세요.

💻 Developer: 작업 시작합니다.

## 재독촉 알림 자동 발송 스크립트 — 닥터프렌즈·건강한할매

### 요구사항 분석
- **트리거:** 6/10 17:00 KST (회신 마감 18:00 KST의 1시간 전)
- **조건:** 회신이 없을 경우에만 발송 (체크 로직 포함)
- **전송 대상:** 사장님 (텔레그램 봇)
- **메시지 내용:** `17:00 KST — 닥터프렌즈·건강한할매 회신 없음, 재독촉 발송 필요`
- **저장 위치:** `sessions/2026-06-10T04-00/developer.md`

### 전체 코드: `cron/reminder_recheck.py`

```python
#!/usr/bin/env python3
"""
reminder_recheck.py — 닥터프렌즈·건강한할매 회신 상태 체크 및 재독촉 알림
- 실행 시간: 매일 17:00 KST (cron: 0 8 * * * UTC = 17:00 KST)
- 조건: 회신 마감 18:00 KST 기준 1시간 전 미회신 시 텔레그램 발송
- 의존: python-telegram-bot, python-dotenv
"""

import os
import json
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path

# 환경변수 로드
from dotenv import load_dotenv
load_dotenv()

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('logs/reminder_recheck.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 설정
KST = timezone(timedelta(hours=9))
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')  # 사장님 채팅 ID
REPLY_STATUS_FILE = Path('data/reply_status.json')  # 회신 상태 저장 파일

# 대상 채널 목록
TARGET_CHANNELS = [
    {"name": "닥터프렌즈", "email": None, "platform": "youtube"},
    {"name": "건강한할매", "email": None, "platform": "youtube"},
]

def load_reply_status() -> dict:
    """회신 상태 파일 로드 (없으면 기본 상태 생성)"""
    if REPLY_STATUS_FILE.exists():
        with open(REPLY_STATUS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {ch["name"]: {"replied": False, "last_checked": None} for ch in TARGET_CHANNELS}

def save_reply_status(status: dict):
    """회신 상태 저장"""
    REPLY_STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(REPLY_STATUS_FILE, 'w', encoding='utf-8') as f:
        json.dump(status, f, ensure_ascii=False, indent=2)

def check_replies(status: dict) -> list:
    """회신 없는 채널 목록 반환"""
    unreplied = []
    for ch in TARGET_CHANNELS:
        if not status.get(ch["name"], {}).get("replied", False):
            unreplied.append(ch["name"])
    return unreplied

def send_telegram_alert(unreplied: list):
    """텔레그램 봇으로 사장님께 알림 발송"""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.error("TELEGRAM_BOT_TOKEN 또는 TELEGRAM_CHAT_ID 미설정")
        return False

    try:
        from telegram import Bot

        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        channel_list = "\n".join(f"• {name}" for name in unreplied)
        message = (
            f"⏰ **17:00 KST — 재독촉 알림**\n\n"
            f"회신 마감(18:00 KST)까지 1시간 남았으나 "
            f"아래 채널에서 아직 회신이 없습니다:\n\n"
            f"{channel_list}\n\n"
            f"**조치 필요:** 재독촉 이메일 발송 또는 DM 재발송"
        )

        bot.send_message(
            chat_id=TELEGRAM_CHAT_ID,
            text=message,
            parse_mode='Markdown'
        )
        logger.info(f"텔레그램 알림 발송 완료 — 미회신 채널: {unreplied}")
        return True

    except Exception as e:
        logger.error(f"텔레그램 발송 실패: {e}")
        return False

def log_result(unreplied: list, sent: bool):
    """결과를 sessions/developer.md에 기록"""
    timestamp = datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
    result = "발송 성공" if sent else "발송 실패"
    log_entry = (
        f"\n## [{timestamp}] 재독촉 알림 실행\n"
        f"- **상태:** {result}\n"
        f"- **미회신 채널:** {', '.join(unreplied) if unreplied else '없음'}\n"
        f"- **다음 액션:** {'재독촉 발송 필요' if unreplied else '대기 — 모든 채널 회신 완료'}\n"
    )

    # sessions 파일에 기록
    sessions_file = Path('sessions/2026-06-10T04-00/developer.md')
    sessions_file.parent.mkdir(parents=True, exist_ok=True)
    with open(sessions_file, 'a', encoding='utf-8') as f:
        f.write(log_entry)

    logger.info(f"로그 기록 완료: {sessions_file}")

def main():
    """메인 실행 함수"""
    now = datetime.now(KST)
    logger.info(f"재독촉 체크 시작 — {now.strftime('%Y-%m-%d %H:%M:%S')} KST")

    # 1. 회신 상태 로드
    status = load_reply_status()
    logger.info(f"회신 상태 로드 완료: {status}")

    # 2. 미회신 채널 확인
    unreplied = check_replies(status)
    logger.info(f"미회신 채널: {unreplied if unreplied else '없음'}")

    # 3. 미회신 있을 때만 알림 발송
    sent = False
    if unreplied:
        sent = send_telegram_alert(unreplied)
    else:
        logger.info("모든 채널 회신 완료 — 알림 불필요")

    # 4. 결과 기록
    log_result(unreplied, sent)

    # 5. 상태 업데이트 (last_checked)
    for ch in TARGET_CHANNELS:
        status[ch["name"]]["last_checked"] = now.isoformat()
    save_reply_status(status)

    logger.info("재독촉 체크 완료")

if __name__ == "__main__":
    main()
```

### cron 설정 (crontab)

```bash
# 매일 17:00 KST = 08:00 UTC 실행
0 8 * * * /usr/bin/python3 /path/to/cron/reminder_recheck.py
```

### 환경변수 설정 (.env)

```
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
```

### 회신 상태 파일 예시: `data/reply_status.json`

```json
{
  "닥터프렌즈": {
    "replied": false,
    "last_checked": "2026-06-10T16:00:00+09:00"
  },
  "건강한할매": {
    "replied": false,
    "last_checked": "2026-06-10T16:00:00+09:00"
  }
}
```

### 수동 회신 상태 업데이트 명령

```bash
# 회신이 오면 replied를 true로 변경
python3 -c "
import json
with open('data/reply_status.json', 'r+') as f:
    data = json.load(f)
    data['닥터프렌즈']['replied'] = True
    f.seek(0)
    json.dump(data, f, ensure_ascii=False, indent=2)
    f.truncate()
"
```

### 사용 방법 요약

1. 위 `reminder_recheck.py`를 서버의 `cron/` 디렉토리에 저장
2. `.env` 파일에 텔레그램 봇 토큰과 사장님 채팅 ID 설정
3. `data/reply_status.json` 초기화 (스크립트 첫 실행 시 자동 생성)
4. crontab에 `0 8 * * *` 라인 추가
5. 회신이 오면 `replied`를 `true`로 업데이트 (수동 또는 이메일 파싱 자동화)

📊 평가: 완료 — 17:00 KST에 미회신 채널을 체크해 텔레그램으로 알림을 발송하는 완전한 스크립트를 작성하고 sessions에 기록함

📝 다음 단계: 서버에 배포 후 `.env`에 실제 텔레그램 봇 토큰과 사장님 채팅 ID를 설정하고 crontab에 등록하세요
