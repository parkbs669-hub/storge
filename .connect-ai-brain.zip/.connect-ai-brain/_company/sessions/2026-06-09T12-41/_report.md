# 📝 CEO 종합 보고서

📷 Instagram: 작업 시작합니다.

**1. 스토리 이미지 기획 및 디자인 의뢰**

**① 6/10 21:00 KST — "내일 오전 11시" 스토리**
- **소스:** 카드뉴스 3차 슬라이드 1장 (유튜브 공개 예고 슬라이드, 1080×1080px)
- **가공:** 1080×1920px 스토리 비율로 확장, 하단 1/3 지점에 흰색 텍스트 스티커 `🕐 내일 오전 11시` (Noto Sans Bold, 48pt, 중앙 정렬, 그림자 효과)
- **배경:** 슬라이드 원본 이미지 위에 검은색 그라데이션 오버레이 (상단 70% 투명 → 하단 100% 불투명)
- **CTA:** "알림 설정" 스티커 아이콘 우측 하단 (링크: 유튜브 영상 URL)

**② 6/11 09:00 KST — "2시간 후 공개" 카운트다운 스토리**
- **디자인:** 단색 배경 (#1A1A2E) + 중앙 대형 텍스트 `⏰ 2시간 후 공개` (흰색, Bold, 72pt)
- **서브텍스트:** `6/11(목) 오전 11시 · 폐렴 백신 영상` (회색 #CCCCCC, Regular, 28pt, 상단 여백 20px)
- **하단:** `#로저범 #폐렴백신` 해시태그 (24pt, 투명도 60%)
- **CTA:** "알림 설정" 스티커 + 유튜브 링크

**2. Meta Business Suite API 스크립트 업데이트**

기존 `insta_scheduler.py`에 스토리 업로드 함수 추가:

```python
# 스토리 업로드 함수
def upload_story(image_path, caption_text, scheduled_time_kst):
    """
    Meta Graph API v19.0으로 스토리 예약 업로드
    - image_path: 로컬 JPG 파일 경로
    - caption_text: 스티커 텍스트 (옵션)
    - scheduled_time_kst: KST datetime 객체
    """
    media_container = graph_api.post(
        f"{INSTAGRAM_BUSINESS_ID}/media",
        params={
            "media_type": "STORIES",
            "image_url": upload_to_cdn(image_path),  # CDN 업로드 필요
            "caption": caption_text,
            "access_token": META_ACCESS_TOKEN
        }
    )
    # 예약 게시 (publish_time은 Unix timestamp UTC)
    publish_time_utc = scheduled_time_kst - timedelta(hours=9)
    graph_api.post(
        f"{INSTAGRAM_BUSINESS_ID}/media_publish",
        params={
            "creation_id": media_container["id"],
            "publish_time": int(publish_time_utc.timestamp()),
            "access_token": META_ACCESS_TOKEN
        }
    )
    return media_container["id"]

# 실행 블록
if __name__ == "__main__":
    # 6/10 21:00 KST 스토리
    story1_id = upload_story(
        image_path="insta_story_1_preview.jpg",
        caption_text="🕐 내일 오전 11시",
        scheduled_time_kst=datetime(2026, 6, 10, 21, 0, 0)
    )
    print(f"[OK] Story 1 예약 완료: {story1_id}")
    
    # 6/11 09:00 KST 카운트다운 스토리
    story2_id = upload_story(
        image_path="insta_story_2_countdown.jpg",
        caption_text="⏰ 2시간 후 공개",
        scheduled_time_kst=datetime(2026, 6, 11, 9, 0, 0)
    )
    print(f"[OK] Story 2 예약 완료: {story2_id}")
    
    # 텔레그램 보고
    send_telegram(f"✅ Instagram 스토리 예약 완료\n"
                  f"1. 6/10 21:00 — 내일 오전 11시\n"
                  f"2. 6/11 09:00 — 2시간 후 공개")
```

**3. Designer 협업 요청 (이미지 제작)**
- **파일 1:** `insta_story_1_preview.jpg` (1080×1920px, 3차 슬라이드 기반 + 텍스트 스티커)
- **파일 2:** `insta_story_2_countdown.jpg` (1080×1920px, 단색 배경 + 카운트다운 디자인)
- **마감:** 6/10 12:00 KST (스크립트 테스트 및 예약 시간 확보)

**4. 텔레그램 자동 보고 (스크립트 내장)**
- 성공 시: `✅ Instagram 스토리 예약 완료 — 6/10 21:00 / 6/11 09:00`
- 실패 시: `❌ Instagram 스토리 예약 실패 — {에러 메시지}`

**5. 후속 스토리 아이디어 (6/11 11:00 영상 공개 직후)**
- **"지금 공개됐습니다 🔴"** 스토리: 유튜브 영상 썸네일 + "시청하기" 스와이프 업 링크
- 게시 시간: 6/11 11:05 KST (공개 후 5분)

📊 평가: 진행중 — 스토리 이미지 2종 디자인이 Designer로부터 나와야 스크립트 최종 테스트 가능

📝 다음 단계: Designer에게 스토리 이미지 2종 제작 의뢰 (6/10 12:00 KST 마감) 후 Meta Business Suite API 스크립트에 반영
