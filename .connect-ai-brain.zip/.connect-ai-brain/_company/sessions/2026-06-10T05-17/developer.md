# 💻 Developer — 인스타그램 DM 발송 또는 SMTP 이메일 발송 중 사용 가능한 방법을 확인하고, researcher가 작성한 DM 초안을 각 크리에이터에게 발송할 수 있는 스크립트를 준비하세요. 발송 전 수신자 계정 유효성 점검 로직을 포함하고, 결과를 sessions/2026-06-10T14-17/developer.md에 저장하세요.

💻 Developer: 작업 시작합니다.

## 인스타그램 DM / SMTP 이메일 발송 가능성 분석 및 스크립트 준비

### 1. 발송 가능성 분석

#### ✅ SMTP 이메일 발송 — **사용 가능**
- 이전 세션(2026-06-10T04-32)에서 이미 SMTP 발송 스크립트로 대체 크리에이터 5인에게 협업 제안 이메일 발송 완료
- SMTP 설정(호스트·포트·계정) 유효성 점검 완료
- **재발송 가능** (단, 이미 발송한 이메일과 중복되지 않도록 DM 초안을 이메일 본문으로 변환)

#### ❌ 인스타그램 DM 발송 — **현재 불가능**
- Instagram Graph API로 DM 발송은 **비즈니스 계정 + 인증된 앱**만 가능
- 현재 Instagram Basic Display API만 사용 중 (읽기 전용)
- DM 발송을 위한 `POST /{ig-user-id}/messages` 엔드포인트는 **Meta Business Suite** 연동 + **pages_manage_metadata** 권한 필요
- 자동화 스크립트로 DM 발송은 불가능 → **수동 DM 발송**만 가능

### 2. 결정: SMTP 이메일 재발송 (DM 초안 → 이메일 본문 변환)

researcher가 작성한 DM 초안 2종(A. 부드러운 리마인더형 / B. 긴급 협업 제안형)을 이메일 본문으로 변환하여 각 크리에이터에게 발송합니다.

### 3. 스크립트: `send_dm_as_email.py`

```python
#!/usr/bin/env python3
"""
send_dm_as_email.py — researcher의 DM 초안을 SMTP 이메일로 발송
사용법: python send_dm_as_email.py [--mode reminder|urgent]
  --mode reminder: 부드러운 리마인더형 (기본값)
  --mode urgent: 긴급 협업 제안형
"""

import os
import sys
import json
import smtplib
import argparse
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

# ── 설정 ──────────────────────────────────────────────
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")      # 환경변수 설정 필수
SMTP_PASS = os.getenv("SMTP_PASS", "")      # 환경변수 설정 필수

# 크리에이터 정보 (이메일 + 이름)
CREATORS = [
    {"name": "닥터프렌즈", "email": "doctorfriends@example.com"},
    {"name": "건강한 할매", "email": "healthygranny@example.com"},
    {"name": "약사아빠의 건강TV", "email": "pharmacistdad@example.com"},
    {"name": "시니어라이프 정보통", "email": "seniorlife@example.com"},
    {"name": "의사가 말하는 건강", "email": "doctorshealth@example.com"},
]

# ── DM 초안 템플릿 (researcher 산출물 기반) ──────��───
DM_TEMPLATES = {
    "reminder": {
        "닥터프렌즈": """안녕하세요, 닥터프렌즈님. 😊
지난번 협업 제안 이메일(6/10 발송) 확인하셨을까요?
저희는 65세 이상 폐렴 백신 무료 접종 캠페인을 준비 중인데,
의료인으로서 신뢰도 높은 닥터프렌즈님과 함께하고 싶습니다.
회신 마감이 6/11(목) 18시까지라 짧게 안내드립니다.
편하실 때 확인 부탁드립니다. 감사합니다!""",
        "건강한 할매": """건강한 할매님, 안녕하세요! 😊
지난번 보내드린 협업 제안 이메일 보셨나요?
저희가 65세 이상 어르신 대상 폐렴 백신 무료 접종 캠페인을 준비 중인데,
할매님의 따뜻한 말투로 전달해주시면 정말 좋을 것 같아요.
회신 마감이 6/11(목) 18시입니다. 부담 없이 확인해주세요!""",
        "약사아빠의 건강TV": """약사아빠님, 안녕하세요! 😊
지난주 보내드린 협업 제안 이메일 확인하셨나요?
65세 이상 폐렴 백신 무료 접종 캠페인인데,
약사이신 약사아빠님의 전문성과 가족 건강 콘텐츠 스타일이 딱 맞습니다.
회신 마감은 6/11(목) 18시입니다. 확인 부탁드립니다!""",
        "시니어라이프 정보통": """시니어라이프 정보통님, 안녕하세요! 😊
지난번 협업 제안 이메일 확인하셨을까요?
65세 이상 폐렴 백신 무료 접종 캠페인을 준비 중입니다.
정보와 혜택을 잘 전달하시는 정보통님 스타일에 딱 맞는 제안입니다.
회신 마감이 6/11(목) 18시입니다. 확인 부탁드립니다!""",
        "의사가 말하는 건강": """의사가 말하는 건강님, 안녕하세요! 😊
지난번 보내드린 협업 제안 이메일 확인하셨나요?
65세 이상 폐렴 백신 무료 접종 캠페인인데,
팩트 기반으로 건강 정보를 전달하시는 스타일이 정말 잘 어울립니다.
회신 마감은 6/11(목) 18시입니다. 확인 부탁드립니다!"""
    },
    "urgent": {
        "닥터프렌즈": """닥터프렌즈님, 긴급 안내드립니다. 🔴
6/11 18시 마감인 협업 제안 건, 아직 회신이 없어 다시 연락드립니다.
[제안 요약]
- 협업비 30만원 + 무료 접종권 10매
- 콘텐츠 1건(인스타 피드/릴스)
- UTM 2종 제공
늦어도 오늘(6/11) 18시까지 회신 부탁드립니다.
늦어도 괜찮으시다면 이 메일에 회신으로라도 알려주세요.""",
        "건강한 할매": """건강한 할매님, 다시 연락드려 죄송합니다. 🙏
6/11 18시 마감인 협업 건, 아직 확인이 안 되어 급히 메일 드립니다.
[제안 요약]
- 협업비 30만원 + 무료 접종권 10매
- 인스타그램 콘텐츠 1건
- UTM 2종 제공
오늘 18시까지 회신 부탁드립니다.
늦어도 괜찮으시면 이 메일로만 답 주셔도 됩니다!""",
        "약사아빠의 건강TV": """약사아빠님, 긴급 연락드립니다. 🔴
6/11 18시 마감 협업 건, 회신이 없어 메일 드립니다.
[제안 요약]
- 협업비 30만원 + 무료 접종권 10매
- 인스타그램 콘텐츠 1건
- UTM 2종 제공
오늘 18시까지 회신 부탁드립니다.""",
        "시니어라이프 정보통": """시니어라이프 정보통님, 긴급 안내드립니다. 🔴
6/11 18시 마감 협업 건, 아직 회신이 없어 다시 연락드립니다.
[제안 요약]
- 협업비 30만원 + 무료 접종권 10매
- 콘텐츠 1건
- UTM 2종 제공
오늘 18시까지 회신 부탁드립니다.""",
        "의사가 말하는 건강": """의사가 말하는 건강님, 긴급 연락드립니다. 🔴
6/11 18시 마감 협업 건, 회신이 없어 메일 드립니다.
[제안 요약]
- 협업비 30만원 + 무료 접종권 10매
- 콘텐츠 1건
- UTM 2종 제공
오늘 18시까지 회신 부탁드립니다."""
    }
}

SUBJECTS = {
    "reminder": "[리마인더] 65세 이상 폐렴 백신 무료 접종 캠페인 협업 제안",
    "urgent": "[긴급] 6/11 18시 마감 — 폐렴 백신 캠페인 협업 제안"
}

def validate_email(email):
    """간단한 이메일 형식 검증"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def send_email(recipient_name, recipient_email, subject, body):
    """SMTP 이메일 발송"""
    msg = MIMEMultipart("alternative")
    msg["From"] = SMTP_USER
    msg["To"] = recipient_email
    msg["Subject"] = subject
    
    # HTML 버전 (선택사항)
    html_body = body.replace("\n", "<br>\n")
    html = f"""<html><body style="font-family: sans-serif; line-height: 1.6;">
<p>{html_body}</p>
<hr>
<p style="color: #888; font-size: 12px;">본 메일은 Rogerbum 캠페인 자동 발송 시스템에서 전송되었습니다.</p>
</body></html>"""
    
    msg.attach(MIMEText(body, "plain", "utf-8"))
    msg.attach(MIMEText(html, "html", "utf-8"))
    
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)
        return {"status": "success", "name": recipient_name, "email": recipient_email}
    except Exception as e:
        return {"status": "fail", "name": recipient_name, "email": recipient_email, "error": str(e)}

def main():
    parser = argparse.ArgumentParser(description="DM 초안을 SMTP 이메일로 발송")
    parser.add_argument("--mode", choices=["reminder", "urgent"], default="reminder",
                        help="발송 모드: reminder(부드러운형) / urgent(긴급형)")
    args = parser.parse_args()
    
    mode = args.mode
    template = DM_TEMPLATES[mode]
    subject = SUBJECTS[mode]
    
    print(f"📧 DM→이메일 발송 시작 | 모드: {mode}")
    print(f"📋 제목: {subject}")
    print(f"👥 대상: {len(CREATORS)}명")
    print("-" * 50)
    
    # 1. 수신자 계정 유효성 점검
    print("🔍 [1/2] 수신자 이메일 유효성 점검 중...")
    valid_creators = []
    invalid_creators = []
    
    for creator in CREATORS:
        if validate_email(creator["email"]):
            valid_creators.append(creator)
            print(f"  ✅ {creator['name']}: {creator['email']} — 유효")
        else:
            invalid_creators.append(creator)
            print(f"  ❌ {creator['name']}: {creator['email']} — 형식 오류")
    
    if invalid_creators:
        print(f"\n⚠️ 유효하지 않은 이메일 {len(invalid_creators)}건 — 발송 제외")
    
    if not valid_creators:
        print("❌ 발송 가능한 수신자가 없습니다. 종료.")
        return
    
    # 2. 이메일 발송
    print(f"\n📤 [2/2] 이메일 발송 중... ({len(valid_creators)}건)")
    results = []
    
    for creator in valid_creators:
        body = template.get(creator["name"], "")
        if not body:
            print(f"  ⚠️ {creator['name']}: 템플릿 없음 — 건너뜀")
            results.append({"status": "skip", "name": creator["name"], "reason": "템플릿 없음"})
            continue
        
        result = send_email(creator["name"], creator["email"], subject, body)
        results.append(result)
        icon = "✅" if result["status"] == "success" else "❌"
        print(f"  {icon} {result['name']} ({result['email']}): {result['status']}")
        if result["status"] == "fail":
            print(f"     오류: {result.get('error', '알 수 없음')}")
    
    # 3. 결과 요약
    success_count = sum(1 for r in results if r["status"] == "success")
    fail_count = sum(1 for r in results if r["status"] == "fail")
    skip_count = sum(1 for r in results if r["status"] == "skip")
    
    print("\n" + "=" * 50)
    print(f"📊 발송 결과 요약")
    print(f"  ✅ 성공: {success_count}건")
    print(f"  ❌ 실패: {fail_count}건")
    print(f"  ⏭️  건너뜀: {skip_count}건")
    print(f"  📋 전체: {len(results)}건")
    
    # 결과 저장
    output = {
        "timestamp": datetime.now().isoformat(),
        "mode": mode,
        "subject": subject,
        "recipient_validation": {
            "valid": [c["email"] for c in valid_creators],
            "invalid": [c["email"] for c in invalid_creators]
        },
        "send_results": results,
        "summary": {
            "success": success_count,
            "fail": fail_count,
            "skip": skip_count,
            "total": len(results)
        }
    }
    
    output_path = "sessions/2026-06-10T14-17/developer.md"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# 💻 Developer — DM→이메일 발송 결과\n\n")
        f.write(f"실행 시간: {output['timestamp']}\n")
        f.write(f"발송 모드: {mode}\n\n")
        f.write("## 수신자 유효성 점검\n\n")
        f.write("| 이름 | 이메일 | 상태 |\n")
        f.write("|------|--------|------|\n")
        for c in CREATORS:
            status = "✅ 유효" if c["email"] in [v["email"] for v in valid_creators] else "❌ 오류"
            f.write(f"| {c['name']} | {c['email']} | {status} |\n")
        f.write("\n## 발송 결과\n\n")
        f.write("| 이름 | 이메일 | 결과 |\n")
        f.write("|------|--------|------|\n")
        for r in results:
            status_icon = {"success": "✅", "fail": "❌", "skip": "⏭️"}.get(r["status"], "❓")
            f.write(f"| {r['name']} | {r['email']} | {status_icon} {r['status']} |\n")
        f.write(f"\n## 요약\n- 성공: {success_count}건\n- 실패: {fail_count}건\n- 건너뜀: {skip_count}건\n")
        f.write(f"\n---\n📝 다음 단계: 텔레그램으로 사장님께 발송 결과 보고\n")
    
    print(f"\n💾 결과 저장 완료: {output_path}")
    
    # 텔레그램 보고용 메시지
    print("\n📱 텔레그램 보고 메시지:")
    print(f"📧 DM→이메일 발송 완료 ({mode} 모드)")
    print(f"✅ 성공 {success_count} / ❌ 실패 {fail_count} / ⏭️ 건너뜀 {skip_count}")
    print(f"📁 상세: sessions/2026-06-10T14-17/developer.md")

if __name__ == "__main__":
    main()
```

### 4. 사용 방법

```bash
# 부드러운 리마인더형 발송 (기본)
python send_dm_as_email.py --mode reminder

# 긴급 협업 제안형 발송
python send_dm_as_email.py --mode urgent
```

### 5. 환경변수 설정 (필수)

```
SMTP_USER=your_email@gmail.com
