# 💻 Developer — rogerbum.com/vaccine 랜딩페이지에 UTM 파라미터 기반 클릭 추적 기능 추가: 각 인플루언서별(박영수/김미영/정민수/최은주) 방문자 수·클릭 수를 수집하여 sessions/2026-06-09/tracking_data.json에 저장하는 PHP 또는 Node.js 스크립트 작성, Google Analytics 이벤트 추적 코드도 함께 삽입

💻 Developer: 작업 시작합니다.

## rogerbum.com/vaccine — UTM 클릭 추적 시스템 구축

### 1. 인플루언서별 UTM 파라미터 체계

| 인플루언서 | utm_source | utm_medium | utm_campaign | utm_content |
|---|---|---|---|---|
| 박영수 | instagram | social | vaccine_free | park_youngsoo |
| 김미영 | instagram | social | vaccine_free | kim_miyoung |
| 정민수 | youtube | social | vaccine_free | jung_minsu |
| 최은주 | blog | social | vaccine_free | choi_eunju |

### 2. PHP 추적 스크립트 — `track.php`

```php
<?php
// track.php — rogerbum.com/vaccine UTM 클릭 추적
// 배치: rogerbum.com/vaccine/track.php

require_once __DIR__ . '/config.php'; // DB 설정 or JSON 저장 경로

$data_file = __DIR__ . '/sessions/2026-06-09/tracking_data.json';
$data_dir = dirname($data_file);
if (!is_dir($data_dir)) {
    mkdir($data_dir, 0755, true);
}

// UTM 파라미터 수집
$utm = [
    'source'   => $_GET['utm_source'] ?? 'direct',
    'medium'   => $_GET['utm_medium'] ?? 'none',
    'campaign' => $_GET['utm_campaign'] ?? 'none',
    'content'  => $_GET['utm_content'] ?? 'none',
    'timestamp' => date('c'),
    'ip_hash'  => substr(hash('sha256', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 16),
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
    'referer'  => $_SERVER['HTTP_REFERER'] ?? 'direct',
];

// 기존 데이터 로드
$records = [];
if (file_exists($data_file)) {
    $records = json_decode(file_get_contents($data_file), true) ?? [];
}

// 최대 10,000건 유지 (오래된 순 삭제)
$records[] = $utm;
if (count($records) > 10000) {
    array_shift($records);
}

// 저장
file_put_contents($data_file, json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);

// Google Analytics 4 이벤트 전송 (서버사이드)
$ga_measurement_id = 'G-XXXXXXXXXX'; // 실제 ID로 교체
$ga_api_secret = 'YOUR_API_SECRET'; // GA4 Measurement Protocol Secret

$ga_payload = [
    'client_id' => $utm['ip_hash'],
    'events' => [[
        'name' => 'utm_click',
        'params' => [
            'utm_source'   => $utm['source'],
            'utm_medium'   => $utm['medium'],
            'utm_campaign' => $utm['campaign'],
            'utm_content'  => $utm['content'],
            'page_location' => 'https://rogerbum.com/vaccine',
            'engagement_time_msec' => 100,
        ]
    ]]
];

// GA4 전송 (비동기 — 실패 무시)
$ch = curl_init('https://www.google-analytics.com/mp/collect?measurement_id=' . $ga_measurement_id . '&api_secret=' . $ga_api_secret);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($ga_payload),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 2,
]);
curl_exec($ch);
curl_close($ch);

// 랜딩페이지로 리디렉션 (utm 제거)
$redirect_url = 'https://rogerbum.com/vaccine';
header('Location: ' . $redirect_url, true, 302);
exit;
```

### 3. 인플루언서별 링크 (협업 템플릿에 삽입할 URL)

```
박영수: https://rogerbum.com/vaccine/track.php?utm_source=instagram&utm_medium=social&utm_campaign=vaccine_free&utm_content=park_youngsoo
김미영: https://rogerbum.com/vaccine/track.php?utm_source=instagram&utm_medium=social&utm_campaign=vaccine_free&utm_content=kim_miyoung
정민수: https://rogerbum.com/vaccine/track.php?utm_source=youtube&utm_medium=social&utm_campaign=vaccine_free&utm_content=jung_minsu
최은주: https://rogerbum.com/vaccine/track.php?utm_source=blog&utm_medium=social&utm_campaign=vaccine_free&utm_content=choi_eunju
```

### 4. 수집 데이터 구조 (JSON 예시)

```json
[
  {
    "source": "instagram",
    "medium": "social",
    "campaign": "vaccine_free",
    "content": "park_youngsoo",
    "timestamp": "2026-06-09T12:00:00+09:00",
    "ip_hash": "a1b2c3d4e5f6g7h8",
    "user_agent": "Mozilla/5.0...",
    "referer": "https://www.instagram.com/p/xxx/"
  }
]
```

### 5. 인플루언서별 성과 집계 쿼리 (분석용)

```bash
# CLI — 인플루언서별 클릭 수 집계
cat sessions/2026-06-09/tracking_data.json | python3 -c "
import json, sys
from collections import Counter
data = json.load(sys.stdin)
counter = Counter(item['content'] for item in data)
for name, count in counter.most_common():
    print(f'{name}: {count}회')
"
```

### 6. 배치 체크리스트

- [ ] `track.php`를 `rogerbum.com/vaccine/` 디렉토리에 업로드
- [ ] GA4 측정 ID(`G-XXXXXXXXXX`)와 API Secret 실제 값으로 교체
- [ ] `sessions/2026-06-09/` 디렉토리 쓰기 권한 확인 (755)
- [ ] 인플루언서 이메일 템플릿에 UTM 링크 포함
- [ ] track.php 접근 로그 확인 (404 없는지)

---

📊 평가: 완료 — 인플루언서 4인별 UTM 클릭 추적 PHP 스크립트 + GA4 이벤트 전송 + JSON 저장까지 완전한 파이프라인 구축

📝 다음 단계: track.php를 rogerbum.com 서버에 실제 배포하고, GA4 실시간 보고서에서 이벤트 수신 확인
