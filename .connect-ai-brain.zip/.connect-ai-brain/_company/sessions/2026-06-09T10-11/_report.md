# 📝 CEO 종합 보고서

💻 Developer: 작업 시작합니다.

## YouTube 댓글 모니터링 자동화 스크립트 (v1.0)

### 개요
- **목적:** 영상 공개 후 첫 1시간, 3단계 체크포인트(3분/10분/30분) 자동 실행
- **API:** YouTube Data API v3 (댓글 목록·답글·삭제·차단)
- **실행 방식:** cron job 3개로 분리 실행 (각 체크포인트 독립적)

### 사전 준비
```bash
pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib python-telegram-bot
```
- 환경변수 설정 (`.env`):
```
YT_API_KEY=AIzaSy...
YT_VIDEO_ID=xxxxx
TELEGRAM_BOT_TOKEN=xxxxx
TELEGRAM_CHAT_ID=xxxxx
```

---

### 1. 공통 모듈: `youtube_comment_utils.py`

```python
#!/usr/bin/env python3
# sessions/2026-06-09T19-11/youtube_comment_utils.py
"""YouTube 댓글 모니터링 공통 유틸리티"""

import os
import json
import time
from datetime import datetime
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from dotenv import load_dotenv

load_dotenv()

YT_API_KEY = os.getenv("YT_API_KEY")
VIDEO_ID = os.getenv("YT_VIDEO_ID")
LOG_DIR = "sessions/2026-06-09T19-11/logs"

# 텔레그램 알림 (선택)
TELEGRAM_ENABLED = os.getenv("TELEGRAM_BOT_TOKEN") and os.getenv("TELEGRAM_CHAT_ID")
if TELEGRAM_ENABLED:
    import telegram
    bot = telegram.Bot(token=os.getenv("TELEGRAM_BOT_TOKEN"))
    chat_id = os.getenv("TELEGRAM_CHAT_ID")

def get_youtube_client():
    """YouTube API v3 클라이언트 생성"""
    return build("youtube", "v3", developerKey=YT_API_KEY)

def log_action(action_type, data):
    """JSON 로그 파일에 기록"""
    os.makedirs(LOG_DIR, exist_ok=True)
    log_file = f"{LOG_DIR}/{datetime.now().strftime('%Y%m%d_%H%M%S')}_{action_type}.json"
    with open(log_file, "w", encoding="utf-8") as f:
        json.dump({"timestamp": datetime.now().isoformat(), "action": action_type, "data": data}, f, ensure_ascii=False, indent=2)
    print(f"[LOG] {log_file} 저장 완료")

def send_telegram(message):
    """텔레그램 알림 발송"""
    if TELEGRAM_ENABLED:
        try:
            bot.send_message(chat_id=chat_id, text=f"[댓글 모니터링] {message}")
        except Exception as e:
            print(f"[WARN] 텔레그램 발송 실패: {e}")

def get_comments(youtube, video_id, max_results=100):
    """영상 댓글 목록 조회 (최대 100개)"""
    comments = []
    try:
        request = youtube.commentThreads().list(
            part="snippet",
            videoId=video_id,
            maxResults=max_results,
            order="time"  # 최신순
        )
        response = request.execute()
        for item in response.get("items", []):
            snippet = item["snippet"]["topLevelComment"]["snippet"]
            comments.append({
                "comment_id": item["id"],
                "author": snippet["authorDisplayName"],
                "text": snippet["textDisplay"].lower(),
                "published_at": snippet["publishedAt"]
            })
    except HttpError as e:
        print(f"[ERROR] 댓글 조회 실패: {e}")
    return comments

def reply_to_comment(youtube, parent_id, text):
    """댓글에 답글 달기"""
    try:
        request = youtube.comments().insert(
            part="snippet",
            body={
                "snippet": {
                    "parentId": parent_id,
                    "textOriginal": text
                }
            }
        )
        response = request.execute()
        return response["id"]
    except HttpError as e:
        print(f"[ERROR] 답글 실패 (comment_id: {parent_id}): {e}")
        return None

def delete_comment(youtube, comment_id):
    """댓글 삭제"""
    try:
        youtube.comments().delete(id=comment_id).execute()
        return True
    except HttpError as e:
        print(f"[ERROR] 삭제 실패 (comment_id: {comment_id}): {e}")
        return False

def block_user(youtube, comment):
    """댓글 작성자 차단 (댓글 삭제 후 별도 처리 필요 — API로 직접 차단은 불가, 로그 기록)"""
    log_action("block_user", {"author": comment["author"], "comment_id": comment["comment_id"]})
    print(f"[BLOCK] 사용자 차단 요청 기록: {comment['author']}")
    return True
```

---

### 2. 체크포인트 1: 3분 — 긍정 댓글 하트 + 감사 답글

```python
#!/usr/bin/env python3
# sessions/2026-06-09T19-11/checkpoint_3min.py
"""3분 체크포인트: 긍정 댓글 감지 → 하트 3개 + 감사 답글"""

from youtube_comment_utils import *
import re

# 긍정 키워드 (소문자 매칭)
POSITIVE_KEYWORDS = ['유익', '감사', '접종', '좋아요', '도움', '고맙', '필요', '맞아야']

# 감사 답글 템플릿
THANK_YOU_TEMPLATES = [
    "유익하게 보셨다니 감사합니다! 😊 폐렴 백신 접종은 65세 이상 무료입니다.",
    "좋은 반응 감사합니다! 접종은 가까운 보건소에서 가능합니다.",
    "도움이 되셨다니 기쁩니다. 건강 챙기세요! 💪"
]

def process_positive_comments(youtube, comments):
    """긍정 댓글 처리: 하트 3개(API 불가 → 답글로 대체) + 감사 답글"""
    processed = []
    for comment in comments:
        text = comment["text"]
        if any(kw in text for kw in POSITIVE_KEYWORDS):
            # 하트 3개: YouTube API는 하트 기능 미지원 → 답글에 하트 이모지 3개 포함
            reply_text = "❤️❤️❤️ " + THANK_YOU_TEMPLATES[0]  # 첫 번째 템플릿 사용
            reply_id = reply_to_comment(youtube, comment["comment_id"], reply_text)
            processed.append({
                "comment_id": comment["comment_id"],
                "author": comment["author"],
                "text": text,
                "reply_id": reply_id,
                "reply_text": reply_text
            })
            print(f"[3MIN] 긍정 댓글 처리: {comment['author']} → 답글 ID: {reply_id}")
            time.sleep(0.5)  # API rate limit 방지
    return processed

def main():
    print("=" * 50)
    print("[3분 체크포인트] 긍정 댓글 모니터링 시작")
    print(f"시간: {datetime.now().isoformat()}")
    print("=" * 50)

    youtube = get_youtube_client()
    comments = get_comments(youtube, VIDEO_ID, max_results=50)

    if not comments:
        print("[INFO] 조회된 댓글이 없습니다.")
        send_telegram("3분 체크포인트: 조회된 댓글 0개")
        return

    processed = process_positive_comments(youtube, comments)
    log_action("checkpoint_3min", {
        "total_comments": len(comments),
        "positive_detected": len(processed),
        "processed": processed
    })

    summary = f"3분 체크포인트 완료: 전체 {len(comments)}개 댓글 중 긍정 {len(processed)}개 처리"
    print(f"\n[완료] {summary}")
    send_telegram(summary)

if __name__ == "__main__":
    main()
```

---

### 3. 체크포인트 2: 10분 — 질문 댓글 → 표준 답변 3종

```python
#!/usr/bin/env python3
# sessions/2026-06-09T19-11/checkpoint_10min.py
"""10분 체크포인트: 질문 댓글 감지 → 표준 답변 자동 게시"""

from youtube_comment_utils import *

# 질문 키워드 → 답변 매핑
QA_RULES = [
    {
        "keywords": ["부작용", "이상반응", "아프", "통증"],
        "answer": "폐렴 백신의 일반적인 부작용은 접종 부위 통증·발적(10~20%)이며, 2~3일 내 자연 소실됩니다. 심각한 이상반응은 0.01% 미만으로 보고됩니다. 접종 후 30분간 의료기관에 머무는 것이 안전합니다."
    },
    {
        "keywords": ["어디서", "접종 장소", "병원", "보건소"],
        "answer": "65세 이상 무료 접종은 전국 보건소 및 지정 의료기관에서 가능합니다. 보건소 방문 시 신분증만 지참하시면 됩니다. 자세한 장소는 네이버 지도에서 '폐렴 백신 접종' 검색하세요."
    },
    {
        "keywords": ["비용", "돈", "가격", "무료"],
        "answer": "65세 이상은 국가예방접종 지원사업으로 무료 접종 가능합니다. 65세 미만은 병원마다 상이(보통 3~8만원), 건강보험 적용 시 50% 본인부담입니다."
    },
    {
        "keywords": ["누가", "대상", "연령", "나이"],
        "answer": "65세 이상 모든 어르신(1961년 이전 출생)이 무료 접종 대상입니다. 만성질환자·면역저하자는 연령 무관 접종 권장 — 담당 의사와 상담하세요."
    }
]

def process_question_comments(youtube, comments):
    """질문 댓글 처리: 키워드 매칭 → 표준 답변 게시"""
    processed = []
    for comment in comments:
        text = comment["text"]
        matched_answer = None
        matched_keyword = None
        for rule in QA_RULES:
            for kw in rule["keywords"]:
                if kw in text:
                    matched_answer = rule["answer"]
                    matched_keyword = kw
                    break
            if matched_answer:
                break

        if matched_answer:
            reply_id = reply_to_comment(youtube, comment["comment_id"], matched_answer)
            processed.append({
                "comment_id": comment["comment_id"],
                "author": comment["author"],
                "question_keyword": matched_keyword,
                "reply_id": reply_id,
                "answer_preview": matched_answer[:50] + "..."
            })
            print(f"[10MIN] 질문 댓글 처리: {comment['author']} (키워드: {matched_keyword}) → 답글 ID: {reply_id}")
            time.sleep(0.5)
    return processed

def main():
    print("=" * 50)
    print("[10분 체크포인트] 질문 댓글 모니터링 시작")
    print(f"시간: {datetime.now().isoformat()}")
    print("=" * 50)

    youtube = get_youtube_client()
    comments = get_comments(youtube, VIDEO_ID, max_results=100)

    if not comments:
        print("[INFO] 조회된 댓글이 없습니다.")
        send_telegram("10분 체크포인트: 조회된 댓글 0개")
        return

    processed = process_question_comments(youtube, comments)
    log_action("checkpoint_10min", {
        "total_comments": len(comments),
        "questions_answered": len(processed),
        "processed": processed
    })

    summary = f"10분 체크포인트 완료: 전체 {len(comments)}개 댓글 중 질문 답변 {len(processed)}개"
    print(f"\n[완료] {summary}")
    send_telegram(summary)

if __name__ == "__main__":
    main()
```

---

### 4. 체크포인트 3: 30분 — 욕설·허위정보 삭제 + 차단

```python
#!/usr/bin/env python3
# sessions/2026-06-09T19-11/checkpoint_30min.py
"""30분 체크포인트: 블랙리스트 키워드 댓글 삭제 + 사용자 차단"""

from youtube_comment_utils import *

# 블랙리스트 키워드 (삭제 대상)
BLACKLIST_KEYWORDS = ['음모', '위험해', '사기', '독', '죽음', '불임', '자폐', '조작', '거짓', '가짜']

def process_blacklist_comments(youtube, comments):
    """블랙리스트 댓글 삭제 + 차단"""
    deleted = []
    for comment in comments:
        text = comment["text"]
        matched_keywords = [kw for kw in BLACKLIST_KEYWORDS if kw in text]
        if matched_keywords:
            # 댓글 삭제
            success = delete_comment(youtube, comment["comment_id"])
            if success:
                # 차단 기록
                block_user(youtube, comment)
                deleted.append({
                    "comment_id": comment["comment_id"],
                    "author": comment["author"],
                    "text": text,
                    "matched_keywords": matched_keywords,
                    "action": "deleted_and_blocked"
                })
                print(f"[30MIN] 삭제+차단: {comment['author']} (키워드: {matched_keywords})")
            time.sleep(0.5)
    return deleted

def main():
    print("=" * 50)
    print("[30분 체크포인트] 블랙리스트 댓글 정리 시작")
    print(f"시간: {datetime.now().isoformat()}")
    print("=" * 50)

    youtube = get_youtube_client()
    comments = get_comments(youtube, VIDEO_ID, max_results=100)

    if not comments:
        print("[INFO] 조회된 댓글이 없습니다.")
        send_telegram("30분 체크포인트: 조회된 댓글 0개")
        return

    deleted = process_blacklist_comments(youtube, comments)
    log_action("checkpoint_30min", {
        "total_comments": len(comments),
        "deleted_count": len(deleted),
        "deleted": deleted
    })

    summary = f"30분 체크포인트 완료: 전체 {len(comments)}개 댓글 중 삭제+차단 {len(deleted)}개"
    print(f"\n[완료] {summary}")
    send_telegram(summary)

if __name__ == "__main__":
    main()
```

---

### 5. cron 설정 (리눅스 기준)

```bash
# crontab -e
# 영상 공개 시간: 6/11(목) 11:00 KST 기준

# 3분 체크포인트 — 11:03
3 11 * * * cd /path/to/project && python3 sessions/2026-06-09T19-11/checkpoint_3min.py >> /var/log/yt_comment_3min.log 2>&1

# 10분 체크포인트 — 11:10
10 11 * * * cd /path/to/project && python3 sessions/2026-06-09T19-11/checkpoint_10min.py >> /var/log/yt_comment_10min.log 2>&1

# 30분 체크포인트 — 11:30
30 11 * * * cd /path/to/project && python3 sessions/2026-06-09T19-11/checkpoint_30min.py >> /var/log/yt_comment_30min.log 2>&1
```

---

### 주요 제약사항 (참고)
1. **YouTube API는 하트(좋아요) 기능 미지원** — 답글에 `❤️❤️❤️` 이모지 포함으로 대체
2. **사용자 차단은 API로 직접 불가** — 차단 요청을 로그에 기록하고, YouTube Studio에서 수동 확인 필요
3. **Rate Limit:** 초당 1회 요청 권장 (스크립트에 `time.sleep(0.5)` 적용)
4. **댓글 필터링:** YouTube Studio에서 사전에 블랙리스트 키워드 필터 설정 권장 (백업)

---

### 사용법
```bash
# 개별 실행
python3 sessions/2026-06-09T19-11/checkpoint_3min.py
python3 sessions/2026-06-09T19-11/checkpoint_10min.py
python3 sessions/2026-06-09T19-11/checkpoint_30min.py

# 로그 확인
cat sessions/2026-06-09T19-11/logs/20260611_*.json | jq .
```

📊 평가: 완
