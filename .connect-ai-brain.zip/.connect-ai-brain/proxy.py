"""
Connect AI Proxy — CEO(Deepseek) + Specialists(Deepseek) + Writer(GPT-4o)
Port: 1234 / OpenAI-compatible API
"""
import json, asyncio, os
import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse


def load_dotenv():
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("=", 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip()
                    if val.startswith('"') and val.endswith('"'):
                        val = val[1:-1]
                    elif val.startswith("'") and val.endswith("'"):
                        val = val[1:-1]
                    os.environ[key] = val

load_dotenv()


def _sanitize(obj):
    """재귀적으로 서로게이트 문자를 UTF-8 replacement char로 교체."""
    if isinstance(obj, str):
        return obj.encode("utf-8", errors="replace").decode("utf-8")
    elif isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_sanitize(v) for v in obj]
    return obj

app = FastAPI()

CLAUDE_API_KEY   = os.getenv("CLAUDE_API_KEY", "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")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "sk-a18cb230a0d6444695c1811664a72137")
OPENAI_API_KEY   = os.getenv("OPENAI_API_KEY", "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")

CLAUDE_API_URL   = "https://api.anthropic.com/v1/messages"
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
OPENAI_API_URL   = "https://api.openai.com/v1/chat/completions"

CLAUDE_MODEL   = "claude-sonnet-4-5"
DEEPSEEK_MODEL = "deepseek-chat"


def is_claude(model: str) -> bool:
    return "claude" in model.lower()


def _is_autonomous_ceo_call(body: dict) -> bool:
    """CEO 호출이 자율 사이클/모닝 브리핑(자동 발생)인지 마지막 user 메시지의 마커로 판별."""
    for m in reversed(body.get("messages", [])):
        if m.get("role") == "user":
            content = m.get("content")
            if isinstance(content, str):
                head = content[:300]
                return "[자율 사이클" in head or "[모닝 브리핑]" in head
            return False
    return False


def resolve_ceo_smart(body: dict) -> str:
    """ceo-smart 별칭: 자율 사이클은 deepseek-reasoner, 사용자 대화·지시는 Claude."""
    return "deepseek-reasoner" if _is_autonomous_ceo_call(body) else CLAUDE_MODEL

def is_openai(model: str) -> bool:
    return "gpt" in model.lower()


def openai_to_claude(body: dict) -> dict:
    """Convert OpenAI format to Claude Messages API format."""
    messages = body.get("messages", [])
    system_content = ""
    user_messages = []

    for m in messages:
        if m["role"] == "system":
            system_content = m["content"]
        else:
            user_messages.append(m)

    claude_body = {
        "model": CLAUDE_MODEL,
        "max_tokens": body.get("max_tokens", 4096),
        "messages": user_messages,
        "stream": body.get("stream", False),
    }
    if system_content:
        claude_body["system"] = system_content
    # Only send temperature OR top_p (not both) — Claude restriction
    if "temperature" in body:
        claude_body["temperature"] = body["temperature"]
    # top_p intentionally excluded to avoid Claude error

    return claude_body


def claude_to_openai(claude_resp: dict, model: str) -> dict:
    """Convert Claude response to OpenAI format."""
    content = ""
    if claude_resp.get("content"):
        for block in claude_resp["content"]:
            if block.get("type") == "text":
                content += block["text"]

    return {
        "id": claude_resp.get("id", "chatcmpl-claude"),
        "object": "chat.completion",
        "model": model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": claude_resp.get("stop_reason", "stop")
        }],
        "usage": claude_resp.get("usage", {})
    }


async def stream_claude(claude_body: dict, model: str):
    """Stream Claude response in OpenAI SSE format."""
    headers = {
        "x-api-key": CLAUDE_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    async with httpx.AsyncClient(timeout=300) as client:
        async with client.stream("POST", CLAUDE_API_URL, headers=headers, json=claude_body) as r:
            async for line in r.aiter_lines():
                if not line or line == "event: ping":
                    continue
                if line.startswith("data:"):
                    data_str = line[5:].strip()
                    if data_str == "[DONE]":
                        yield "data: [DONE]\n\n"
                        break
                    try:
                        data = json.loads(data_str)
                        # Convert Claude stream event to OpenAI format
                        delta_text = ""
                        if data.get("type") == "content_block_delta":
                            delta_text = data.get("delta", {}).get("text", "")
                        elif data.get("type") == "message_delta":
                            pass  # finish event

                        chunk = {
                            "id": "chatcmpl-claude",
                            "object": "chat.completion.chunk",
                            "model": model,
                            "choices": [{
                                "index": 0,
                                "delta": {"content": delta_text} if delta_text else {},
                                "finish_reason": None
                            }]
                        }
                        yield f"data: {json.dumps(chunk)}\n\n"
                    except Exception:
                        continue


@app.get("/v1/models")
async def list_models():
    return {
        "object": "list",
        "data": [
            {"id": "ceo-smart",        "object": "model"},
            {"id": "claude-sonnet",    "object": "model"},
            {"id": "deepseek-chat",    "object": "model"},
            {"id": "deepseek-reasoner","object": "model"},
            {"id": "gpt-4o",           "object": "model"},
        ]
    }


@app.post("/v1/chat/completions")
async def chat(request: Request):
    body = _sanitize(await request.json())
    model = body.get("model", "deepseek-chat")
    stream = body.get("stream", False)

    if model == "ceo-smart":
        model = resolve_ceo_smart(body)
        body["model"] = model

    if is_claude(model):
        claude_body = openai_to_claude(body)

        if stream:
            return StreamingResponse(
                stream_claude(claude_body, model),
                media_type="text/event-stream"
            )
        else:
            headers = {
                "x-api-key": CLAUDE_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }
            async with httpx.AsyncClient(timeout=300) as client:
                r = await client.post(CLAUDE_API_URL, headers=headers, json=claude_body)
                return JSONResponse(claude_to_openai(r.json(), model))

    elif is_openai(model):
        # GPT-4o — OpenAI API (OpenAI 형식 그대로 전달)
        headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }
        if stream:
            async def stream_openai():
                async with httpx.AsyncClient(timeout=300) as client:
                    async with client.stream("POST", OPENAI_API_URL, headers=headers, json=body) as r:
                        async for chunk in r.aiter_bytes():
                            yield chunk
            return StreamingResponse(stream_openai(), media_type="text/event-stream")
        else:
            async with httpx.AsyncClient(timeout=300) as client:
                r = await client.post(OPENAI_API_URL, headers=headers, json=body)
                return JSONResponse(r.json())

    else:
        # Deepseek — pass through as OpenAI format
        body["model"] = DEEPSEEK_MODEL if "reasoner" not in model else "deepseek-reasoner"
        if "reasoner" in model:
            body.pop("temperature", None)
            body.pop("top_p", None)
            body.pop("presence_penalty", None)
            body.pop("frequency_penalty", None)
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json",
        }
        if stream:
            async def stream_deepseek():
                async with httpx.AsyncClient(timeout=300) as client:
                    async with client.stream("POST", DEEPSEEK_API_URL, headers=headers, json=body) as r:
                        async for chunk in r.aiter_bytes():
                            yield chunk
            return StreamingResponse(stream_deepseek(), media_type="text/event-stream")
        else:
            async with httpx.AsyncClient(timeout=300) as client:
                r = await client.post(DEEPSEEK_API_URL, headers=headers, json=body)
                return JSONResponse(r.json())


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=1234)
