# Connect AI Memory Cleanup Script
# Archived entries go to memory_archive.md (AI does NOT read this file)
# Only memory.md is read by Connect AI agents
# Usage: powershell -ExecutionPolicy Bypass -File cleanup_memory.ps1
# Usage (dry run): ... -DryRun

param(
    [int]$MaxEntries = 5,
    [switch]$DryRun
)

$brainPath = "$env:USERPROFILE\.connect-ai-brain\_company\_agents"
$totalCleaned = 0

Write-Host ""
Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  Connect AI Memory Cleanup" -ForegroundColor Cyan
Write-Host "  Max entries per agent: $MaxEntries" -ForegroundColor Cyan
Write-Host "  Archive -> memory_archive.md (AI skips this)" -ForegroundColor Cyan
if ($DryRun) { Write-Host "  [DRY RUN - no changes]" -ForegroundColor Yellow }
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

$memoryFiles = Get-ChildItem -Path $brainPath -Filter "memory.md" -Recurse

foreach ($file in $memoryFiles) {
    $agentName = Split-Path (Split-Path $file.FullName) -Leaf
    $agentDir  = Split-Path $file.FullName
    $archivePath = Join-Path $agentDir "memory_archive.md"

    $content = Get-Content $file.FullName -Encoding UTF8

    $allEntries  = @()
    $headerLines = @()
    $inHeader    = $true

    foreach ($line in $content) {
        if ($inHeader -and $line -notmatch "^- \[\d{4}-\d{2}-\d{2}\]") {
            $headerLines += $line
            continue
        }
        if ($line -match "^- \[\d{4}-\d{2}-\d{2}\]") {
            $inHeader = $false
            $allEntries += $line
        }
    }

    # Keep only the latest MaxEntries in memory.md
    if ($allEntries.Count -le $MaxEntries) {
        Write-Host "  [OK]   $agentName - $($allEntries.Count) entries (no trim needed)" -ForegroundColor Green
        continue
    }

    $keepEntries    = $allEntries[($allEntries.Count - $MaxEntries)..($allEntries.Count - 1)]
    $archiveEntries = $allEntries[0..($allEntries.Count - $MaxEntries - 1)]
    $cleanedCount   = $archiveEntries.Count

    Write-Host "  [TRIM] $agentName - kept $($keepEntries.Count), moved $cleanedCount to memory_archive.md" -ForegroundColor Yellow

    if (-not $DryRun) {
        # Overwrite memory.md with only recent entries
        $newMemory = $headerLines + $keepEntries
        Set-Content -Path $file.FullName -Value $newMemory -Encoding UTF8

        # Append old entries to memory_archive.md
        $today = Get-Date -Format "yyyy-MM-dd HH:mm"
        $archiveHeader = @("", "## Archived on $today", "")
        Add-Content -Path $archivePath -Value ($archiveHeader + $archiveEntries) -Encoding UTF8
    }

    $totalCleaned += $cleanedCount
}

Write-Host ""
Write-Host "======================================" -ForegroundColor Cyan
if ($DryRun) {
    Write-Host "  [DRY RUN] $totalCleaned entries would move to memory_archive.md" -ForegroundColor Yellow
} else {
    Write-Host "  Done: $totalCleaned entries moved to memory_archive.md" -ForegroundColor Green
    Write-Host "  AI reads  : memory.md only (lean)" -ForegroundColor Green
    Write-Host "  Archive at: memory_archive.md (AI skips)" -ForegroundColor Gray
}
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""
