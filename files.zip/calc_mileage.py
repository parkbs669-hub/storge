# -*- coding: utf-8 -*-
"""
일비 신청용 방문 거리(km) 자동 계산 프로그램
------------------------------------------------
사용법:
    python calc_mileage.py <입력파일.xlsx> <출력파일.xlsx> [--ref 참조파일.xlsx] [--sheet 시트명]

입력파일 : 년도 | 방문 월 | 방문 일 | 출발지 | 도착지 | 거리(km)  컬럼을 가진 xlsx.
           거리(km)이 이미 채워진 행은 건드리지 않고, 빈 행만 계산해서 채운다.
참조파일 : 과거 데이터가 들어있는 마스터 마일리지 파일
           (기본값: "20232025년_마일리지_계산_SHP_방문_결과입력.xlsx",
            RAW / 3월 합계 / 4월 합계 시트 사용)

동작 규칙 (사용자 지정):
 - 거리는 반드시 '기존 참조 데이터'에서만 가져온다. 웹 검색이나 추정은 하지 않는다.
 - 방문지 문자열에 여러 기관이 나열돼 있어도, 그 지역을 대표하는 지역명(첫 행정구역 키)을
   기준으로 참조 데이터를 찾는다. (예: '안동시보건소,의회,시청' -> '안동시' 기준)
 - 참조 데이터가 아예 없거나, 과거 값이 여러 개로 갈려 애매한 경우(동률)는
   자동으로 채우지 않고 빈칸으로 두고 "확인필요" 시트에 사유와 함께 남긴다.
 - Home <-> 지역 구간만 자동 계산 대상이다. '숙소'/'숙소이동'이 낀 구간은
   숙박지가 매번 달라 일반화할 수 없으므로 자동 계산 대상에서 제외한다(직접 입력 필요).
"""
import sys
import os
import argparse
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from region_key import is_home_anchor, is_lodging_anchor, extract_first_key
from distance_reference import build_distance_reference

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

CONFIDENT = "자동채움"
AMBIGUOUS = "확인필요(과거값 여러개)"
NO_MATCH = "확인필요(참조데이터 없음)"
NOT_APPLICABLE = "직접입력필요(숙소구간)"
KEEP = "기존값유지"

DEFAULT_REF_FILE = "20232025년_마일리지_계산_SHP_방문_결과입력.xlsx"
DEFAULT_REF_SHEETS = ["RAW", "3월 합계", "4월 합계"]


def best_value(counter: Counter):
    if not counter:
        return None, NO_MATCH
    items = counter.most_common()
    if len(items) == 1:
        return items[0][0], CONFIDENT
    top_count = items[0][1]
    tied = [v for v, c in items if c == top_count]
    if len(tied) == 1:
        return items[0][0], CONFIDENT
    return None, AMBIGUOUS


def lookup_distance(ref, origin, dest):
    """반환: (거리값 또는 None, 지역키, 방향, 상태)"""
    if is_lodging_anchor(origin) or is_lodging_anchor(dest):
        return None, None, None, NOT_APPLICABLE

    origin_home = is_home_anchor(origin)
    dest_home = is_home_anchor(dest)

    if origin_home and not dest_home:
        key = extract_first_key(dest)
        if not key:
            return None, key, "to", NO_MATCH
        v, status = best_value(ref[key]["to"]) if key in ref else (None, NO_MATCH)
        return v, key, "to", status
    elif dest_home and not origin_home:
        key = extract_first_key(origin)
        if not key:
            return None, key, "from", NO_MATCH
        v, status = best_value(ref[key]["from"]) if key in ref else (None, NO_MATCH)
        return v, key, "from", status
    else:
        return None, None, None, NOT_APPLICABLE


def process(input_path, output_path, ref_paths, input_sheet=None):
    ref, n_ref_rows = build_distance_reference(ref_paths)
    print(f"[참조표] {len(ref)}개 지역 키, 과거 {n_ref_rows}건 기준으로 구축 완료")

    wb_in = openpyxl.load_workbook(input_path, data_only=True)
    sheet_name = input_sheet or wb_in.sheetnames[0]
    ws_in = wb_in[sheet_name]

    rows = list(ws_in.iter_rows(values_only=True))
    header = rows[0]
    data_rows = []
    for row in rows[1:]:
        if row is None or all(v is None for v in row):
            continue
        if row[0] is not None and "Total" in str(row[0]):
            continue
        data_rows.append(list(row))

    results = []
    review = []
    filled = 0
    for row in data_rows:
        while len(row) < 6:
            row.append(None)
        yr, mo, day, origin, dest, dist = row[:6]
        if dist is not None:
            results.append(row + [KEEP])
            continue
        val, key, direction, status = lookup_distance(ref, origin, dest)
        if status == CONFIDENT:
            row[5] = val
            filled += 1
        results.append(row + [status])
        if status != CONFIDENT:
            review.append([yr, mo, day, origin, dest, key, direction, status])

    # ---- 출력 워크북 작성 ----
    wb_out = openpyxl.Workbook()
    ws1 = wb_out.active
    ws1.title = "결과"
    header_font = Font(name="맑은 고딕", size=10, bold=True)
    body_font = Font(name="맑은 고딕", size=10)
    fill_head = PatternFill("solid", fgColor="D9E1F2")

    cols = list(header[:6]) + ["처리상태"]
    ws1.append(cols)
    for c in ws1[1]:
        c.font = header_font
        c.fill = fill_head
        c.alignment = Alignment(horizontal="center")

    for r in results:
        ws1.append(r)
    for row_cells in ws1.iter_rows(min_row=2):
        for c in row_cells:
            c.font = body_font

    ws2 = wb_out.create_sheet("확인필요")
    ws2.append(["년도", "방문 월", "방문 일", "출발지", "도착지", "추출된 지역키", "방향", "사유"])
    for c in ws2[1]:
        c.font = header_font
        c.fill = fill_head
        c.alignment = Alignment(horizontal="center")
    for r in review:
        ws2.append(r)
    for row_cells in ws2.iter_rows(min_row=2):
        for c in row_cells:
            c.font = body_font

    for ws in (ws1, ws2):
        for col_cells in ws.columns:
            length = max((len(str(c.value)) if c.value is not None else 0) for c in col_cells)
            ws.column_dimensions[col_cells[0].column_letter].width = max(10, length + 2)

    wb_out.save(output_path)
    print(f"[완료] 총 {len(data_rows)}건 중 자동채움 {filled}건, 확인필요/직접입력 {len(review)}건")
    print(f"[출력] {output_path}")


def main():
    ap = argparse.ArgumentParser(description="일비 신청 거리(km) 자동 계산")
    ap.add_argument("input", help="새 방문기록 입력 xlsx (년도/방문월/방문일/출발지/도착지, 거리는 빈칸 가능)")
    ap.add_argument("output", help="결과를 저장할 xlsx 경로")
    ap.add_argument("--ref", action="append", dest="ref_files",
                     help=f"참조 파일 경로 (기본값: {DEFAULT_REF_FILE}) 여러 번 지정 가능")
    ap.add_argument("--sheet", default=None, help="입력 파일에서 읽을 시트명 (기본: 첫 시트)")
    args = ap.parse_args()

    ref_files = args.ref_files or [DEFAULT_REF_FILE]
    ref_paths = [(f, DEFAULT_REF_SHEETS) for f in ref_files]
    process(args.input, args.output, ref_paths, args.sheet)


if __name__ == "__main__":
    main()
