# -*- coding: utf-8 -*-
"""
지역 키(region key) 추출 유틸리티

예: '안동시보건소,의회,시청' -> '안동시'
방문지 문자열 안에서 맨 처음 등장하는 행정구역명(시/군/구/읍/면 등)을
그 방문지를 대표하는 '기준 지역'으로 뽑아낸다.
(사용자 규칙: 여러 기관이 나열돼 있어도 그 지역을 대표하는 지역명을 기준으로 삼는다)
"""
import re

# 참조표 구축 기준점은 'Home' 왕복 구간만 사용한다.
# '숙소'/'숙소이동'은 그날그날 숙박 장소가 달라 Home 기준 거리·통행료와
# 비교할 수 없으므로 별도 취급(참조표에 섞지 않음, 자동 채움 대상 아님).
HOME_ANCHORS = {"home"}
LODGING_ANCHORS = {"숙소", "숙소이동"}

def is_home_anchor(text):
    if text is None:
        return False
    return str(text).strip().lower() in HOME_ANCHORS

def is_lodging_anchor(text):
    if text is None:
        return False
    return str(text).strip() in LODGING_ANCHORS

# 시/군/구/읍/면 등으로 끝나는, 1~4글자 지명을 앞에서부터 찾는다.
SUFFIX_PATTERN = re.compile(
    r'[가-힣]{1,4}(?:광역시|특별자치시|특별자치도|특별시|시|군|구|읍|면)'
)

def extract_first_key(text):
    """방문지 문자열에서 맨 처음 등장하는 행정구역 키를 반환. 없으면 None."""
    if not text:
        return None
    t = str(text).strip()
    m = SUFFIX_PATTERN.search(t)
    return m.group(0) if m else None

def root_of(key):
    """지역 키에서 접미(시/군/구 등)를 뗀 순수 지명 root 반환. 예: '안동시'->'안동'"""
    if not key:
        return None
    for suf in ("광역시", "특별자치시", "특별자치도", "특별시", "시", "군", "구", "읍", "면"):
        if key.endswith(suf):
            return key[: -len(suf)]
    return key

def root_candidates(key):
    """게이트/지명 매칭에 사용할 후보 문자열 목록 (root 우선, 너무 짧으면 원본도 포함)."""
    r = root_of(key)
    if r and len(r) >= 2:
        return [r, key]
    return [key]
