# -*- coding: utf-8 -*-
"""
방문(거리) 데이터 기반 하이패스 월별 명세서 자동 생성 프로그램
================================================================
사용법:
    python make_hipass.py --month 5 --year 2026 \
        --mileage 5월_마일리지.xlsx \
        --master 20232025년_마일리지_계산_SHP_방문_결과입력.xlsx \
        --toll 2026년_하이패스.xls \
        --template 2026년_4월_하이패스.xls \
        --output 2026년_5월_하이패스.xls

동작 원리:
 1. 하이패스 전체 사용내역(--toll)의 각 거래일자를, 마일리지 데이터(--master, --mileage)의
    방문일자와 연결해서 "이 지역을 갈 때는 어떤 게이트 조합을 쓰는지" 경로 패턴을 학습한다.
 2. 대상 월(--month)의 방문 기록을 여행 단위(Home 출발 ~ Home 복귀)로 묶고,
    각 여행의 지역에 해당하는 과거 경로 패턴을 찾아 통행 기록을 생성한다.
 3. 금액은 게이트 쌍별로 하이패스 내역에서 '가장 최근' 실제 거래금액을 쓴다 (요금 인상 반영).
 4. 과거에 실제로 간 적이 있는데 통행 기록이 없었던 지역(대구 시내 등)은 통행료 없음으로 처리.
    과거 참조가 아예 없는 지역은 기록을 만들지 않고 콘솔에 "확인필요"로 보고한다 (추정 금지).
 5. 출력 파일은 하이패스 홈페이지 명세서(--template, 4월 파일)와 동일한 서식으로 만든다.
"""
import argparse
import datetime
import re
import sys
from collections import defaultdict

import openpyxl
import xlrd
import xlwt

# ---------------------------------------------------------------
# 공통: 문자열/날짜 정리
# ---------------------------------------------------------------
HOME = {"home"}
LODGING = {"숙소", "숙소이동"}
# 집(대구) 쪽 게이트: 이 게이트가 입구면 '출발(갈 때)', 출구면 '복귀(올 때)' 기록으로 본다
HUB_GATES = {"북대구", "남대구", "서대구", "동대구", "대구", "대구2", "수성", "동명동호"}
# 방문지 토큰 매칭에서 무시할 일반 명사 (어느 지역에나 붙는 말)
GENERIC_TOKENS = {"의회", "농협", "축협", "보건소", "시청", "군청", "구청", "시의회",
                  "보건의료원", "소방서", "소방본부", "복지관", "하나로", "숙소이동", "숙소"}

SUFFIX_PATTERN = re.compile(r'[가-힣]{1,4}(?:광역시|특별자치시|특별자치도|특별시|시|군|구|읍|면)')


def is_home(v):
    return v is not None and str(v).strip().lower() in HOME


def is_lodging(v):
    return v is not None and str(v).strip() in LODGING


def region_key(text):
    if not text:
        return None
    m = SUFFIX_PATTERN.search(str(text).strip())
    return m.group(0) if m else None


def tokens_of(text):
    """방문지 문자열을 기관 단위 토큰으로 분해 (일반 명사는 제외)."""
    if not text:
        return set()
    parts = re.split(r'[,\s/·]+', str(text).strip())
    out = set()
    for p in parts:
        p = p.strip()
        if len(p) >= 3 and p not in GENERIC_TOKENS:
            out.add(p)
    return out


def norm_int(v, strip_suffix=""):
    if v is None:
        return None
    s = str(v)
    if strip_suffix:
        s = s.replace(strip_suffix, "")
    digits = re.sub(r'\D', '', s)
    return int(digits) if digits else None


# ---------------------------------------------------------------
# 1) 마일리지 데이터 로드 -> 여행(trip) 단위로 묶기
# ---------------------------------------------------------------
def load_mileage_rows(path, sheets=None):
    wb = openpyxl.load_workbook(path, data_only=True)
    names = sheets or wb.sheetnames
    rows = []
    for sn in names:
        if sn not in wb.sheetnames:
            continue
        for row in wb[sn].iter_rows(min_row=2, values_only=True):
            if not row or all(v is None for v in row):
                continue
            if row[0] is not None and "Total" in str(row[0]):
                continue
            y = norm_int(row[0], "년")
            m = norm_int(row[1], "월")
            d = norm_int(row[2], "일")
            if y is None or m is None or d is None:
                continue
            if not (1 <= m <= 12 and 1 <= d <= 31 and 2020 <= y <= 2030):
                continue
            try:
                date = datetime.date(y, m, d)
            except ValueError:
                continue
            rows.append((date, row[3], row[4]))
    return rows


def group_trips(rows):
    """행들을 여행 단위(Home 출발 ~ Home 복귀)로 묶는다.
    반환: [{start, end, region, tokens, dates}, ...]"""
    trips = []
    cur = None
    for date, origin, dest in rows:
        if is_home(origin):
            if cur:
                trips.append(cur)
            cur = {"start": date, "end": date, "region": region_key(dest),
                   "tokens": tokens_of(dest), "dates": {date}}
            if is_home(dest):
                cur = None
                continue
        elif cur is None:
            # 숙소 출발 등으로 시작하는 고아 구간 -> 단독 여행으로 취급
            cur = {"start": date, "end": date, "region": region_key(origin),
                   "tokens": tokens_of(origin), "dates": {date}}
        cur["end"] = max(cur["end"], date)
        cur["dates"].add(date)
        if not is_home(dest) and not is_lodging(dest):
            cur["tokens"] |= tokens_of(dest)
            if cur["region"] is None:
                cur["region"] = region_key(dest)
        if is_home(dest):
            trips.append(cur)
            cur = None
    if cur:
        trips.append(cur)
    # 중복 제거 (같은 시작일+지역이 여러 시트에 있을 수 있음)
    seen = {}
    for t in trips:
        k = (t["start"], t["region"], frozenset(t["tokens"]))
        seen[k] = t
    return sorted(seen.values(), key=lambda t: t["start"])


# ---------------------------------------------------------------
# 2) 하이패스 내역 로드
# ---------------------------------------------------------------
def load_toll_records(xls_path):
    wb = xlrd.open_workbook(xls_path, formatting_info=True)
    records = []
    seen = set()
    for si in range(wb.nsheets):
        sh = wb.sheet_by_index(si)
        for r in range(sh.nrows):
            row = sh.row_values(r)
            if len(row) < 9:
                continue
            num = row[1]
            if not (isinstance(num, float) and num > 0):
                continue
            raw_date, gin, gout, amt = row[2], row[4], row[6], row[8]
            if not gin or not gout or not isinstance(amt, (int, float)):
                continue
            date = None
            if isinstance(raw_date, float):
                y, m, d, *_ = xlrd.xldate_as_tuple(raw_date, wb.datemode)
                date = datetime.date(y, m, d)
            else:
                mobj = re.match(r'(\d{4})[/.-](\d{1,2})[/.-](\d{1,2})', str(raw_date))
                if mobj:
                    date = datetime.date(*map(int, mobj.groups()))
            if date is None:
                continue
            # 명세서 파일에 같은 월 블록이 (번호만 다르게) 중복으로 붙어있는 경우가 있어
            # (날짜, 입구, 출구, 금액)이 완전히 같은 레코드는 한 번만 사용
            key = (date, str(gin).strip(), str(gout).strip(), float(amt))
            if key in seen:
                continue
            seen.add(key)
            records.append({"date": date, "in": str(gin).strip(),
                            "out": str(gout).strip(), "amt": float(amt)})
    return records


# ---------------------------------------------------------------
# 3) 경로 패턴 학습 (하이패스 거래일 <-> 방문일 조인)
# ---------------------------------------------------------------
def learn_patterns(trips, toll_records):
    """반환:
    pattern_by_region: 지역키 -> {"recs": [...], "src": 출처날짜}
    pattern_by_token : 토큰   -> {"recs": [...], "src": 출처날짜}
                       (여러 지역에 걸쳐 나타나는 애매한 토큰은 제외)
    latest_amount    : 게이트쌍(방향무관) -> 가장 최근 거래금액
    no_toll_regions  : 통행료 없이 다녀온 것이 확인된 지역 -> 가장 최근 날짜
    """
    by_date = defaultdict(list)
    latest_amount = {}
    latest_amount_date = {}
    covered_months = set()
    for rec in toll_records:
        by_date[rec["date"]].append(rec)
        covered_months.add((rec["date"].year, rec["date"].month))
        pair = frozenset((rec["in"], rec["out"]))
        if pair not in latest_amount_date or rec["date"] >= latest_amount_date[pair]:
            latest_amount_date[pair] = rec["date"]
            latest_amount[pair] = rec["amt"]

    # 토큰 애매성 검사: 한 토큰이 서로 다른 지역의 여행에 나타나면 매칭에 쓰지 않는다
    # (예: '남구보건소'는 대구/부산/포항 어디에나 등장)
    token_regions = defaultdict(set)
    for t in trips:
        for tok in t["tokens"]:
            token_regions[tok].add(t["region"])
    ambiguous = {tok for tok, regs in token_regions.items() if len(regs) > 1}

    pattern_by_region = {}
    pattern_by_token = {}
    region_date = {}
    token_date = {}
    no_toll_regions = {}

    for t in trips:
        recs = []
        for d in sorted(t["dates"]):
            for rec in by_date.get(d, []):
                recs.append({"in": rec["in"], "out": rec["out"], "amt": rec["amt"],
                             "offset": (d - t["start"]).days})
        trip_covered = any((d.year, d.month) in covered_months for d in t["dates"])
        if recs:
            if t["region"]:
                if t["region"] not in region_date or t["start"] >= region_date[t["region"]]:
                    region_date[t["region"]] = t["start"]
                    pattern_by_region[t["region"]] = {"recs": recs, "src": t["start"]}
            for tok in t["tokens"]:
                if tok in ambiguous:
                    continue
                if tok not in token_date or t["start"] >= token_date[tok]:
                    token_date[tok] = t["start"]
                    pattern_by_token[tok] = {"recs": recs, "src": t["start"]}
        elif trip_covered:
            # 하이패스 내역이 있는 달에 다녀왔는데 통행 기록이 없음 = 무료 도로 이동
            if t["region"]:
                prev = no_toll_regions.get(t["region"])
                if prev is None or t["start"] > prev:
                    no_toll_regions[t["region"]] = t["start"]

    return pattern_by_region, pattern_by_token, latest_amount, no_toll_regions


def _related_key(key, candidates):
    """key와 포함관계에 있는 지역키를 candidates에서 찾는다.
    예: '대구달서구' <-> '달서구', '대구중구' <-> '대구'"""
    if not key:
        return None
    best = None
    for c in candidates:
        if len(c) >= 2 and (c in key or key in c):
            if best is None or len(c) > len(best):
                best = c
    return best


def find_pattern(trip, pattern_by_region, pattern_by_token, no_toll_regions):
    """여행에 맞는 패턴 찾기. 반환 (records|None, 상태문자열)"""
    r = trip["region"]
    # 1) 지역키 정확 일치
    if r and r in pattern_by_region:
        p = pattern_by_region[r]
        return p["recs"], f"지역키 '{r}' 패턴 사용 (출처 {p['src']})"
    # 2) 지역키 정확 일치 - 무료 확인
    if r and r in no_toll_regions:
        return [], f"지역키 '{r}': 과거({no_toll_regions[r]})에도 통행료 없음(무료 도로)"
    # 3) 기관명 토큰 매칭 (지역이 하나로 특정되는 토큰만)
    for tok in sorted(trip["tokens"], key=len, reverse=True):
        if tok in pattern_by_token:
            p = pattern_by_token[tok]
            return p["recs"], f"기관명 '{tok}' 패턴 사용 (출처 {p['src']})"
    # 4) 지역키 포함관계 매칭 ('대구달서구' <-> '달서구' 등)
    rel = _related_key(r, no_toll_regions.keys())
    if rel:
        return [], f"유사 지역 '{rel}': 과거({no_toll_regions[rel]})에도 통행료 없음(무료 도로)"
    rel = _related_key(r, pattern_by_region.keys())
    if rel:
        p = pattern_by_region[rel]
        return p["recs"], f"유사 지역 '{rel}' 패턴 사용 (출처 {p['src']})"
    return None, "참조 데이터 없음 -> 확인필요"


# ---------------------------------------------------------------
# 4) 대상 월 통행 기록 생성
# ---------------------------------------------------------------
def generate_month_records(month_trips, pattern_by_region, pattern_by_token,
                           latest_amount, no_toll_regions):
    out_records = []
    report = []
    for t in month_trips:
        recs, note = find_pattern(t, pattern_by_region, pattern_by_token, no_toll_regions)
        label = f"{t['start'].month}/{t['start'].day} {('/'.join(sorted(t['tokens']))[:30] or t['region'] or '?')}"
        if recs is None:
            report.append((t, None, note))
            continue
        if not recs:
            report.append((t, 0, note))
            continue
        made = []
        for rec in recs:
            # 날짜 배정: 입구가 대구쪽 게이트면 출발일, 출구가 대구쪽이면 복귀일
            if rec["in"] in HUB_GATES and rec["out"] not in HUB_GATES:
                date = t["start"]
            elif rec["out"] in HUB_GATES and rec["in"] not in HUB_GATES:
                date = t["end"]
            else:
                date = min(t["start"] + datetime.timedelta(days=rec["offset"]), t["end"])
            pair = frozenset((rec["in"], rec["out"]))
            amt = latest_amount.get(pair, rec["amt"])
            made.append({"date": date, "in": rec["in"], "out": rec["out"], "amt": amt})
        out_records.extend(made)
        report.append((t, len(made), note))
    out_records.sort(key=lambda r: r["date"])
    for i, rec in enumerate(out_records, start=1):
        rec["num"] = i
    out_records.sort(key=lambda r: (r["date"], r["num"]), reverse=True)
    return out_records, report


# ---------------------------------------------------------------
# 5) 4월 파일과 동일한 서식으로 xls 출력
# ---------------------------------------------------------------
def _style(font_h, bold, halign, borders=True, gray=False, numfmt=None):
    st = xlwt.XFStyle()
    f = xlwt.Font()
    f.name = "나눔고딕"
    f.height = font_h
    f.bold = bold
    st.font = f
    al = xlwt.Alignment()
    al.horz = halign
    al.vert = xlwt.Alignment.VERT_CENTER
    st.alignment = al
    if borders:
        b = xlwt.Borders()
        b.left = b.right = b.top = b.bottom = xlwt.Borders.THIN
        st.borders = b
    if gray:
        p = xlwt.Pattern()
        p.pattern = xlwt.Pattern.SOLID_PATTERN
        p.pattern_fore_colour = 22  # 연한 회색 (원본 파일과 동일 색 인덱스)
        st.pattern = p
    if numfmt:
        st.num_format_str = numfmt
    return st


def write_statement_as_new_sheet(existing_path, output_path, sheet_label, records, year, month):
    """기존 하이패스 파일(existing_path)을 열어, sheet_label(예: '5월') 이름의 새 시트를
    추가하고 그 안에 4월 형식과 동일한 명세서를 쓴다. 기존 시트/내용은 그대로 유지."""
    from xlutils.copy import copy as xl_copy

    rb = xlrd.open_workbook(existing_path, formatting_info=True)
    wb = xl_copy(rb)

    existing_names = {rb.sheet_by_index(i).name for i in range(rb.nsheets)}
    name = sheet_label
    suffix = 2
    while name in existing_names:
        name = f"{sheet_label}({suffix})"
        suffix += 1
    ws = wb.add_sheet(name)

    # 기존 첫 시트의 열 너비를 그대로 사용 (있으면)
    col_widths = {0: 1984, 1: 2282, 2: 1088, 3: 2432, 4: 2432,
                  5: 2432, 6: 2432, 7: 6528, 8: 725, 9: 1792, 10: 1920}
    try:
        tsh = rb.sheet_by_index(0)
        for c, ci in tsh.colinfo_map.items():
            col_widths[c] = ci.width
    except Exception:
        pass
    for c, w in col_widths.items():
        ws.col(c).width = w

    C, R = xlwt.Alignment.HORZ_CENTER, xlwt.Alignment.HORZ_RIGHT
    title_st = _style(300, True, C, borders=False)
    label_st = _style(180, True, C, gray=True)
    value_st = _style(180, False, C)
    total_st = _style(180, True, R, borders=False)
    head_st = _style(180, True, C, gray=True)
    num_st = _style(160, False, C)
    txt_st = _style(160, False, C)
    amt_st = _style(160, False, R, numfmt="#,##0_ ")

    total_amt = sum(r["amt"] for r in records)
    n = len(records)

    ws.write_merge(1, 1, 0, 7, "기간별 사용내역", title_st)
    ws.write_merge(3, 3, 0, 1, "카드구분", label_st)
    ws.write_merge(3, 3, 2, 7, "전체", value_st)
    ws.write_merge(4, 4, 0, 1, "조회 구분", label_st)
    last_day = (datetime.date(year + (month == 12), (month % 12) + 1, 1)
                - datetime.timedelta(days=1)).day
    period = f"{year}년 {month:02d}월 01일 ~ {year}년 {month:02d}월 {last_day}일"
    ws.write_merge(4, 4, 2, 7, period, value_st)
    ws.write_merge(5, 5, 0, 7, f"(총 {n}건 / 총액 {int(total_amt):,}원)", total_st)

    ws.write(6, 0, "번호", head_st)
    ws.write_merge(6, 6, 1, 2, "거래일시", head_st)
    ws.write_merge(6, 6, 3, 4, "입구", head_st)
    ws.write_merge(6, 6, 5, 6, "출구", head_st)
    ws.write(6, 7, "거래금액", head_st)

    r = 7
    for rec in records:
        ws.write(r, 0, rec["num"], num_st)
        ws.write_merge(r, r, 1, 2, rec["date"].strftime("%Y/%m/%d"), txt_st)
        ws.write_merge(r, r, 3, 4, rec["in"], txt_st)
        ws.write_merge(r, r, 5, 6, rec["out"], txt_st)
        ws.write(r, 7, rec["amt"], amt_st)
        r += 1

    for i in range(max(r, 8)):
        ws.row(i).height_mismatch = True
        ws.row(i).height = 570 if i == 1 else 400

    wb.save(output_path)
    return name, n, total_amt


def write_statement(output_path, records, year, month, template_path=None):
    wb = xlwt.Workbook(encoding="utf-8")
    ws = wb.add_sheet("Page 1")

    # 열 너비 / 행 높이 (4월 원본 파일에서 읽은 값)
    col_widths = {0: 1984, 1: 2282, 2: 1088, 3: 2432, 4: 2432,
                  5: 2432, 6: 2432, 7: 6528, 8: 725, 9: 1792, 10: 1920}
    if template_path:
        try:
            twb = xlrd.open_workbook(template_path, formatting_info=True)
            tsh = twb.sheet_by_index(0)
            for c, ci in tsh.colinfo_map.items():
                col_widths[c] = ci.width
        except Exception:
            pass
    for c, w in col_widths.items():
        ws.col(c).width = w

    C, R = xlwt.Alignment.HORZ_CENTER, xlwt.Alignment.HORZ_RIGHT
    title_st = _style(300, True, C, borders=False)
    label_st = _style(180, True, C, gray=True)
    value_st = _style(180, False, C)
    total_st = _style(180, True, R, borders=False)
    head_st = _style(180, True, C, gray=True)
    num_st = _style(160, False, C)
    txt_st = _style(160, False, C)
    amt_st = _style(160, False, R, numfmt="#,##0_ ")

    total_amt = sum(r["amt"] for r in records)
    n = len(records)

    ws.write_merge(1, 1, 0, 7, "기간별 사용내역", title_st)
    ws.write_merge(3, 3, 0, 1, "카드구분", label_st)
    ws.write_merge(3, 3, 2, 7, "전체", value_st)
    ws.write_merge(4, 4, 0, 1, "조회 구분", label_st)
    last_day = (datetime.date(year + (month == 12), (month % 12) + 1, 1)
                - datetime.timedelta(days=1)).day
    period = f"{year}년 {month:02d}월 01일 ~ {year}년 {month:02d}월 {last_day}일"
    ws.write_merge(4, 4, 2, 7, period, value_st)
    ws.write_merge(5, 5, 0, 7, f"(총 {n}건 / 총액 {int(total_amt):,}원)", total_st)

    ws.write(6, 0, "번호", head_st)
    ws.write_merge(6, 6, 1, 2, "거래일시", head_st)
    ws.write_merge(6, 6, 3, 4, "입구", head_st)
    ws.write_merge(6, 6, 5, 6, "출구", head_st)
    ws.write(6, 7, "거래금액", head_st)

    r = 7
    for rec in records:
        ws.write(r, 0, rec["num"], num_st)
        ws.write_merge(r, r, 1, 2, rec["date"].strftime("%Y/%m/%d"), txt_st)
        ws.write_merge(r, r, 3, 4, rec["in"], txt_st)
        ws.write_merge(r, r, 5, 6, rec["out"], txt_st)
        ws.write(r, 7, rec["amt"], amt_st)
        r += 1

    for i in range(max(r, 8)):
        ws.row(i).height_mismatch = True
        ws.row(i).height = 570 if i == 1 else 400

    wb.save(output_path)
    return n, total_amt


# ---------------------------------------------------------------
# main
# ---------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="방문 데이터 기반 하이패스 월별 명세서 생성")
    ap.add_argument("--month", type=int, required=True)
    ap.add_argument("--year", type=int, default=2026)
    ap.add_argument("--mileage", required=True, help="대상 월 방문기록이 있는 마일리지 xlsx")
    ap.add_argument("--master", required=True, help="과거 방문기록 마스터 xlsx (RAW 포함)")
    ap.add_argument("--toll", action="append", required=True,
                    help="하이패스 사용내역 xls (여러 번 지정 가능, 전체 내역 권장)")
    ap.add_argument("--template", default=None,
                     help="새 시트를 추가할 기존 하이패스 xls (지정하면 그 파일에 월 시트를 추가; "
                          "미지정시 --toll로 준 파일 중 첫 번째 파일에 추가)")
    ap.add_argument("--sheet-name", default=None,
                     help="추가할 시트 이름 (기본값: '{month}월')")
    ap.add_argument("--new-file", action="store_true",
                     help="기존 파일에 시트를 추가하는 대신, 완전히 새로운 xls 파일(Page 1)로 만든다")
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    # 1) 과거 방문 이력 (마스터 + 대상월 파일 모두)
    hist_rows = load_mileage_rows(args.master) + load_mileage_rows(args.mileage)
    all_trips = group_trips(hist_rows)

    # 2) 하이패스 내역
    toll_records = []
    for p in args.toll:
        toll_records.extend(load_toll_records(p))
    print(f"[하이패스] {len(toll_records)}건 로드, "
          f"커버 월: {sorted(set((r['date'].year, r['date'].month) for r in toll_records))}")

    # 3) 경로 패턴 학습 (대상 월 이전 데이터만 사용)
    target_first = datetime.date(args.year, args.month, 1)
    past_trips = [t for t in all_trips if t["start"] < target_first]
    pat_region, pat_token, latest_amt, no_toll = learn_patterns(past_trips, toll_records)
    print(f"[패턴] 지역 {len(pat_region)}개 / 기관명 {len(pat_token)}개 / "
          f"무료확인 지역 {len(no_toll)}개 학습 완료")

    # 4) 대상 월 여행 -> 통행 기록 생성
    month_trips = [t for t in all_trips
                   if t["start"].year == args.year and t["start"].month == args.month]
    records, report = generate_month_records(month_trips, pat_region, pat_token,
                                             latest_amt, no_toll)

    print("\n===== 여행별 처리 결과 =====")
    for t, cnt, note in report:
        dest = t["region"] or "/".join(sorted(t["tokens"]))[:24] or "?"
        d = f"{t['start'].month}/{t['start'].day}"
        if t["end"] != t["start"]:
            d += f"~{t['end'].day}"
        if cnt is None:
            print(f"  [확인필요] {d} {dest}: {note}")
        elif cnt == 0:
            print(f"  [통행료없음] {d} {dest}: {note}")
        else:
            print(f"  [생성 {cnt}건] {d} {dest}: {note}")

    if args.new_file:
        n, total = write_statement(args.output, records, args.year, args.month, args.template)
        print(f"\n[완료] 새 파일 생성: 총 {n}건 / 총액 {int(total):,}원 -> {args.output}")
    else:
        base_file = args.template or args.toll[0]
        sheet_label = args.sheet_name or f"{args.month}월"
        name, n, total = write_statement_as_new_sheet(
            base_file, args.output, sheet_label, records, args.year, args.month)
        print(f"\n[완료] '{base_file}' 파일 기준으로 시트 '{name}' 추가: "
              f"총 {n}건 / 총액 {int(total):,}원 -> {args.output}")


if __name__ == "__main__":
    main()
