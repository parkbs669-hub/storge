# -*- coding: utf-8 -*-
"""
기존 마일리지 파일(RAW 및 월별 합계 시트)에서
'지역 키 -> Home 기준 거리(km)' 참조표를 만든다.
"""
from collections import defaultdict, Counter
import openpyxl
from region_key import is_home_anchor, is_lodging_anchor, extract_first_key

REQUIRED_COLS = ["년도", "방문 월", "방문 일", "출발지", "도착지", "거리(km)"]


def _rows_from_workbook(path, sheet_names=None):
    wb = openpyxl.load_workbook(path, data_only=True)
    names = sheet_names or wb.sheetnames
    for sn in names:
        if sn not in wb.sheetnames:
            continue
        ws = wb[sn]
        header_seen = False
        for row in ws.iter_rows(values_only=True):
            if not header_seen:
                header_seen = True
                continue
            if row is None or all(v is None for v in row):
                continue
            yield row


def build_distance_reference(reference_files):
    """
    reference_files: [(파일경로, [시트명, ...]), ...]
    반환: {지역키: {"to": Counter(거리), "from": Counter(거리)}}
    "to"   = Home -> 지역 (갈 때)
    "from" = 지역 -> Home (올 때)
    """
    ref = defaultdict(lambda: {"to": Counter(), "from": Counter()})
    n_rows = 0
    for path, sheets in reference_files:
        for row in _rows_from_workbook(path, sheets):
            if len(row) < 6:
                continue
            _, _, _, origin, dest, dist = row[:6]
            if dist is None or origin is None or dest is None:
                continue
            try:
                dist_val = float(dist)
            except (TypeError, ValueError):
                continue

            origin_home = is_home_anchor(origin)
            dest_home = is_home_anchor(dest)
            origin_lodging = is_lodging_anchor(origin)
            dest_lodging = is_lodging_anchor(dest)

            # Home <-> 지역 구간만 참조표에 반영 (숙소 구간/장소간 이동은 제외)
            if origin_home and not dest_home and not dest_lodging:
                key = extract_first_key(dest)
                if key:
                    ref[key]["to"][dist_val] += 1
                    n_rows += 1
            elif dest_home and not origin_home and not origin_lodging:
                key = extract_first_key(origin)
                if key:
                    ref[key]["from"][dist_val] += 1
                    n_rows += 1
    return ref, n_rows
